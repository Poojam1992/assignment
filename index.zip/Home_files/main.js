$(document).ready(function() {

	// Initialize video media info
	var myVideos = $('.abbv-video-player');
	myVideos.each(function(){
		var that = this;
		var vidID = $(this).find('.video-js').attr('id');
		var player = videojs(vidID);
		player.on('loadstart',function(){
			if($('.abbv-carousel[data-playlist-for="'+vidID+'"]').length != 0){
				initScrollButtons($('.abbv-carousel[data-playlist-for="'+vidID+'"]'));
			}
			$(that).find('h3').html(this.mediainfo.name);
			$(that).find('p').html(this.mediainfo.description);
			$(that).find('a.transcript-link').attr("href",this.mediainfo.longDescription);
		});
		setTimeout(function(){initScrollThumbnail($(that).find('.video-js'));},1000);
		player.on('playing', function() {
			var playList = $(player.el_).attr("data-playlist-video-id");
			if(playList) {
				initScrollThumbnail($(player.el_));

			}
		});
		player.ready(function() {
			var playList = $(player.el_).attr("data-playlist-video-id");
			if(playList) {
				initScrollThumbnail($(player.el_));

			}
		});
	});
	// Create carousel scrollers
	var carousels = $('.abbv-carousel');
	carousels.each(function(){
		var that = this;
		var scrollContainer = $(this).find('.abbv-scroll-container');
		var incrementClass = '.'+this.dataset.scrollIncrement;
		var controls = $(this).find('.abbv-scroll');
		// console.log($('.vjs-playlist-thumbnail').length);
		controls.each(function(){
			$(this).on('click',function(){
				var direction;
				if(this.dataset.scrollDirection == 'up' || this.dataset.scrollDirection == 'left'){
					direction = -1;
				} else{ direction = 1; }
				var increment = $(incrementClass).outerHeight(true) * direction;
				var currentPos = $(scrollContainer).scrollTop();
				var newPos = currentPos + increment;
				$(scrollContainer).animate({scrollTop:newPos}, 500, function(){
					// console.log(newPos);
				});
				// console.log(newPos);
				checkArrows(that, newPos);
			});
		});		
	});		
	var reInitArrows = debounce(function(){
		var myPlaylists = $('.abbv-video-playlist');
		myPlaylists.each(function(){
			var temp = $(this).find('.abbv-carousel');
			// $(temp).find('.abbv-scroll-container').scrollTop(0);
			initScrollButtons(temp);
		});
	},500);
	$(window).on("resize", reInitArrows);

	if(campaignTracking.isFTvidTracked()){
		var loadRequestVid = urlObj.getParam('ftvid');
		var $sVidCheck = $('[data-video-id="'+loadRequestVid+'"]');
		var $pVidCheck = $('[data-playlist-video-id="'+loadRequestVid+'"]');
		var $videoFound;
		if($sVidCheck.length != 0 || $pVidCheck.length !=0) {
			// console.log('found the video');
			$videoFound = $sVidCheck.length != 0 ? $sVidCheck : $pVidCheck;
			// console.log('video is: '+ $videoFound.attr('id'));
			// Check if video is modal
			if($videoFound.closest('.abbv-modal').length != 0) {
				abbvModal.openModal($videoFound.closest('.abbv-modal'),'hashTrigger');
				activateDimmer('abbvModal.closeModal');
				// console.log('video lives in modal');
			} 
			// Check if video is in accordion
			else if ($videoFound.closest('.abbv-accordion').length != 0) {
				// console.log('video lives in accordion');
				$videoFound.closest('.abbv-accordion-blade').click()
				videojs($videoFound.attr('id')).autoplay('muted');
			} 
			// Otherwise it lives on page
			else {
				// console.log('video lives on page');
				// console.log('bringing into view than playing');
				$('body, html').scrollTop($videoFound.offset().top - (fixedTracking.getOffset('top')+15));
				videojs($videoFound.attr('id')).autoplay('muted');
			}			
			setTimeout(function(){
				campaignTracking.init();
			},3000);
		} else {
			console.warn('ftvid does not match a video on the page');
		}
	}
});


window.onload = function(){
	var myPlaylists = $('.abbv-video-playlist');
	var playlistItems = $(".vjs-playlist-item");
	myPlaylists.each(function(){
		initScrollButtons($(this).find('.abbv-carousel'));
	});
	playlistItems.each(function(i, item){
		$(item).on('click',function(){
			var videoList = $(this).parents(".abbv-video-player.abbv-video-playlist");
			var imgpos = $(this).position().top;
			videoList.find('.abbv-scroll-container').animate({scrollTop:imgpos}, 500, function(){});
		 });
	 });
};
function initScrollButtons(carouselObj){
	var toDo = $(carouselObj).find('.abbv-playlist-container').outerHeight() - $(carouselObj).find('.vjs-playlist').outerHeight() < 0 ? false : true;
	$(carouselObj).find('.abbv-scroll')[1].disabled = toDo;
}
function initScrollThumbnail($videoFound){
	var videoList = $videoFound.parents(".abbv-video-player.abbv-video-playlist");
	var videoListPos = videoList.find(".vjs-playlist-item.vjs-selected").position();
	if(videoList.length != 0 && videoListPos) {
		var imgpos = videoListPos.top;
		videoList.find('.abbv-scroll-container').animate({scrollTop:imgpos}, 500, function(){});
		// console.log($videoFound.parents('.abbv-video-player').find('.abbv-carousel'));
		var carouselObjAdj = $videoFound.parents('.abbv-video-player').find('.abbv-carousel')
		checkArrows(carouselObjAdj,imgpos);
	}
}
function checkArrows(carouselObj, newPos){
	var arrows = $(carouselObj).find('.abbv-scroll');
	var magicNumber = $(carouselObj).find('.vjs-playlist').outerHeight() - $(carouselObj).find('.abbv-playlist-container').outerHeight() ;
	// console.log(magicNumber);
	if(newPos < 0 ){arrows[0].disabled = true; arrows[1].disabled = false; 
		// console.log('hit top');
	} else if(newPos < magicNumber){arrows[0].disabled = false; arrows[1].disabled = false; 
		// console.log('in mid');
	} else{arrows[1].disabled = true; arrows[0].disabled = false; 
		// console.log('hit bottom');
	}
}

// AbbVie Tabs Component
$(document).ready(function() {
    $('.abbv-tab.abbv-active').fadeTo(300,1)
    // Add classes to first and last tabs that will be visible on mobile
    $('.abbv-tabs-controls').each(function(){
        $(this).find('.abbv-tab-control:not(.abbv-hide-mobile):last').addClass('mobile-notHid-last');
        $(this).find('.abbv-tab-control:not(.abbv-hide-mobile):first').addClass('mobile-notHid-first');
    });
    // Set Tab
    $(".abbv-tab-link").on('click',function() {
        var $tabComponent = $(this).closest(".abbv-tabs");
        var $tabSelected = $(this).parent();
        var $containerSelected = $tabComponent.find("#"+this.dataset.href);
        // // Active State
        $tabSelected.siblings(".abbv-tab-control").removeClass("abbv-active");
        $tabSelected.addClass("abbv-active");
        // // Hide All Tabs
        $containerSelected.siblings(".abbv-tab").hide().removeClass("abbv-active");
        // // Show Clicked Tab
        $tabComponent.find("#"+this.dataset.href).addClass("abbv-active").fadeTo(300,1);
        if($containerSelected.find('.abbv-img-slider').length != 0){
            $containerSelected.find('.abbv-img-slider').each(function(){
                initSlider(this);
            });
        }
    });
    $(window).on("resize", adjustTabs);
});
// Selects first shown tab on mobile if resized to breakpoint with a hidden tab selected
var adjustTabs = debounce(function(){
    //If resized to mobile breakpoint
    if($(window).width() < 600 && $('.abbv-tab-control.abbv-active.abbv-hide-mobile').length != 0){
        console.log('needs swap');
        //Check if any selected tabs have mobile hide class
        $('.abbv-tab-control.abbv-active.abbv-hide-mobile').each(function(){
            // Get tab component specific to change needed
            var $tabComponent = $(this).closest(".abbv-tabs");
            var $firstAvailable = $(this).siblings('.mobile-notHid-first');
            // Hide and remove active container
            $tabComponent.find(".abbv-tab").hide().removeClass("abbv-active");
            // Remove active on tab the tab that will be hidden
            $(this).removeClass('abbv-active');
            // Get the first available/visible tab in grouping and select by adding active class
            $firstAvailable.addClass('abbv-active');
            // Get corresponding tab container and fade in
            $tabComponent.find("#"+$firstAvailable.children('.abbv-tab-link').attr('data-href')).addClass("abbv-active").fadeTo(300,1);
        });
    }
},500);
$(document).ready(function() {
    //On submit send email
    $('.btn-submit-email').on('click', function(e) {
        e.preventDefault();
        var formSubmitted = $(this).closest('.abbv-send-email-form');
        formSubmitted.find('.abbv-error-msg').text('');
        //Initiate send email form
        abbvSendEmail.init(formSubmitted);
    });
    //On Cancel Email
    $('.btn-cancel-email').on('click', function(e) {
        e.preventDefault();
        var formCanceled = $(this).closest('.abbv-send-email-form');
        formCanceled.find('.abbv-error-msg').text('');
        abbvSendEmail.cancelEmail(formCanceled);
    });

    $('.abbv-send-email .main-error button').on('click', function() {
        var $sendEmailObj = $(this).closest('.abbv-send-email');
        $sendEmailObj.find('.main-error').removeClass('abbv-active');
        $sendEmailObj.find('.loading').hide();
        abbvSendEmail.clearForm($sendEmailObj);
    });

    $('.abbv-send-email .main-success button').on('click', function() {
        var $sendEmailObj = $(this).closest('.abbv-send-email');
        $sendEmailObj.find('.main-success').removeAttr('style');
        $sendEmailObj.find('.loading').hide();
        abbvSendEmail.clearForm($sendEmailObj);
    });
});

var abbvSendEmail = (function() {
    var $sendEmailContainer;
    var $sendEmailForm;
    var regexGroup;
    var $senderName;
    var $senderEmail;
    var $recipientName;
    var $recipientEmail;
    var share_url;
    var dynamic_share_api;
    var sEResponse = {};
    return {
        init: function(formS) {
            $sendEmailContainer = formS.closest('.abbv-send-email');
            $sendEmailForm = formS;
            $senderName = $sendEmailForm.find('.senderName');
            $senderEmail = $sendEmailForm.find('.senderEmail');
            $recipientName = $sendEmailForm.find('.recipientName');
            $recipientEmail = $sendEmailForm.find('.recipientEmail');
            share_url = $sendEmailForm.attr("data-share-url");
            dynamic_share_api = $sendEmailForm.attr("data-share-api");
            sEResponse.onSuccess = $sendEmailContainer.find('.main-success span').attr('data-success-msg') == undefined ? "Your message has successfully been sent" : $sendEmailContainer.find('.main-success span').attr('data-success-msg');
            sEResponse.onError = $sendEmailContainer.find('.main-error span').attr('data-err-no-api') == undefined ? "Something went wrong, please try again later" : $sendEmailContainer.find('.main-error span').attr('data-err-no-api');
            regexGroup = {
                userNameExp: /^\s*[a-zA-Z-_.‘’#,'+&]+(?:[\s-][a-zA-Z-_.‘’#,'+&]+)*\s*$/,
                emailExp: /^((\s*[^`~!$%^?&*'=<>()}{|\/\[\]\\.#,;:\s+@"]+(\.[^<>()\[\]\\.,;:\s+@\"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9_]+\.)+[a-zA-Z]{2,6}))+\s*$/
            };
            this.postEmail();
        },
        isValidName: function(userName) {
            return (regexGroup.userNameExp.test(userName) ? true : false);
        },
        isValidEmail: function(email) {
            return (regexGroup.emailExp.test(email) ? true : false);
        },
        isValidForm: function() {
            var sendEmailObj = {};
            var senderNameVal = $senderName.val();
            var recipientNameVal = $recipientName.val();
            var senderEmailVal = $senderEmail.val();
            var recipientEmailVal = $recipientEmail.val();
            $sendEmailForm.find('.abbv-error-msg').hide();
            if (!this.isValidName(senderNameVal)) {
                var $senderNameErrMsg = $senderName.parent().find('.abbv-error-msg');
                $senderNameErrMsg.show().text($senderNameErrMsg.attr('data-err-msg'));
                $senderName.focus();
                return false;
            }
            if (!this.isValidEmail(senderEmailVal)) {
                var $senderEmailErrMsg = $senderEmail.parent().find('.abbv-error-msg');
                $senderEmailErrMsg.show().text($senderEmailErrMsg.attr('data-err-msg'));
                $senderEmail.focus();
                return false;
            }
            if (!this.isValidName(recipientNameVal) && recipientNameVal.length > 0) {
                var $recipientNameErrMsg = $recipientName.parent().find('.abbv-error-msg');
                $recipientNameErrMsg.show().text($recipientNameErrMsg.attr('data-err-msg'))
                $recipientName.focus();
                return false;
            }
            if (!this.isValidEmail(recipientEmailVal) && recipientEmailVal.length > 0) {
                var $recipientEmailErrMsg = $recipientEmail.parent().find('.abbv-error-msg');
                $recipientEmailErrMsg.show().text($recipientEmailErrMsg.attr('data-err-msg'))
                $recipientEmail.focus();
                return false;
            }
            sendEmailObj.senderName = senderNameVal;
            sendEmailObj.senderEmail = senderEmailVal;
            sendEmailObj.recipientName = recipientNameVal;
            sendEmailObj.recipientEmail = recipientEmailVal;
            return sendEmailObj;
        },
        buildPayload: function(sendEmail_obj) {
        	var share_url_link = (share_url === undefined || share_url === '') ? window.location.pathname : share_url;
        	if( share_url_link === undefined || share_url_link === ''){
        		sendEmail_obj.sharePageLink = window.location.origin;
        	}else if( share_url_link.indexOf("/") == 0 ) {
        		sendEmail_obj.sharePageLink = window.location.origin + share_url_link;
        	}else{
        		sendEmail_obj.sharePageLink = share_url_link;
        	}
            return JSON.stringify(sendEmail_obj);
        },
        postEmail: function() {
            var validFormObj = this.isValidForm();
            var sendEmail_API = dynamic_share_api +".sites-share-url";
            var sendEmail_URL = sendEmail_API;
            if (validFormObj && sendEmail_API !== '') {
                $sendEmailContainer.find('.loading').show();
                $sendEmailContainer.find('.abbv-animation-loading').show();
                var payload = this.buildPayload(validFormObj);
                ajaxCall(sendEmail_URL, "POST", payload, onSucessSendEmail, onFailedSendEmail, true);
                //On Successful send email
                function onSucessSendEmail(data) {
                    $sendEmailContainer.find('.abbv-animation-loading').hide();
                    $sendEmailContainer.find('.main-success').show();
                    $sendEmailContainer.find('.main-success span').text(sEResponse.onSuccess);
                }
                //On failed to send email
                function onFailedSendEmail() {
                    $sendEmailContainer.find('.abbv-animation-loading').hide();
                    $sendEmailContainer.find('.main-error').addClass('abbv-active');
                    $sendEmailContainer.find('.main-error span').text(sEResponse.onError);
                }
            } else if (!validFormObj) {
                console.warn("Invalid Form");
            } else {
                console.warn("Check sendEmail API endpoint");
            }
        },
        clearForm: function(formC) {
            var $formC = formC;
            $formC.find('.senderName').val('');
            $formC.find('.senderEmail').val('');
            $formC.find('.recipientName').val('');
            $formC.find('.recipientEmail').val('');
            $formC.find('.abbv-error-msg').text('');
        },
        cancelEmail: function(formC) {
            abbvSendEmail.clearForm(formC);
        }
    };
})();
$(document).ready(function() { 
    abbvSectionNav.init();
});

var abbvSectionNav = (function(){
    var sections = [];
    var $activeSection;
    var openIcon;
    var closeIcon;
    return {
        init : function(){
            $activeSection =  $('.section-navigation-list li a.subnav-active'); 
            $(window).on('scroll', throttle(this.checkSection,250));
            
            // Get all the sections and store to sections variable
            $('.section-navigation-list a').each(function(){
                sections.push($(this.getAttribute("href")));
            });
            //Mobile Navigation Click
            $('.abbv-section-navigation ul li a').click(function(e) {
                var target = $(this).attr('href');
                var $temp = $('.abbv-sticky[data-stick-behavior="scroll-display"]');
                if($temp.length != 0){ $(window).off("scroll", scrollToFixed); }
                if($(".mobile-section-navigation").is(":visible")) {
                    e.preventDefault();
                    abbvSectionNav.closeMenu($(target));
                } else {
                    $('body, html').animate({scrollTop: $(target).offset().top - fixedTracking.getOffset('top',$(target).offset().top) }, 'slow', function(){
                        $(window).on("scroll", scrollToFixed);
                        fixedTracking.scrollToFixedTracking();
                    });
                }
            });
            // Click Next Section
            $('.mobile-section-navigation #section-nav-next').click(function(e) {
                abbvSectionNav.nextSection();
            });
            // Click Previous Section
            $('.mobile-section-navigation #section-nav-prev').click(function(e) {
                var $temp = $('.abbv-sticky[data-stick-behavior="scroll-display"]');
                if($temp.length != 0){ $(window).off("scroll", scrollToFixed); }
                abbvSectionNav.previousSection();
            });
            //Open Mobile Menu
            $('.mobile-section-navigation #section-nav-menu').click(function(e) {
                var that = this;
                if(!$('.abbv-section-navigation').hasClass('abbv-fixed')){
                    $('body, html').animate({scrollTop: $('.abbv-section-navigation').offset().top - fixedTracking.getOffset('top') +10 }, 'slow', 
                        function(){ if($(that).hasClass(openIcon)){ abbvSectionNav.openMenu(); } }
                    );
                } else {
                    if($(this).hasClass(openIcon)){ abbvSectionNav.openMenu(); }
                    else { abbvSectionNav.closeMenu(); }
                }

            });
            openIcon = $('.mobile-section-navigation #section-nav-menu').attr('data-icon-open');
            closeIcon = $('.mobile-section-navigation #section-nav-menu').attr('data-icon-close');
        },
        checkSection : function(){ 
            // This should be attached to scroll listener (throttled) & also fired once after page loads
            var position = window.pageYOffset;
            sections.forEach(function (section) {
                var target = $(section).offset().top - (fixedTracking.getOffset('top')+10);
                var id = $(section).attr('id');
                var navLinks = $('.section-navigation-list li a');
                if (position >= target) {
                    navLinks.removeClass('subnav-active');
                    $activeSection = $('.section-navigation-list li a[href="#' + id + '"]').addClass('subnav-active');    
                    var mobileText = $activeSection.html();
                    abbvSectionNav.updateLocIndicator(mobileText);
                }
            });
        },
        nextSection : function(){
            var $targetLink = $activeSection.parent().next().find('a');
            var target = $targetLink.attr('href');
            if(target) {
            $('body, html').delay(1).animate({scrollTop: $(target).offset().top - fixedTracking.getOffset('top') }, 'slow');
            }
        },
        previousSection : function(){
            var $targetLink = $activeSection.parent().prev().find('a');
            var target = $targetLink.attr('href');
            if(target) {
                $('body, html').delay(1).animate({scrollTop: $(target).offset().top - fixedTracking.getOffset('top') -1 }, 'slow', function(){
                    $(window).on("scroll", scrollToFixed);
                    fixedTracking.scrollToFixedTracking();
                });
            }
        },
        updateLocIndicator : function(value){
            //every time a link is clicked or a scroll into new section occurs 
            // this should be called to update the inner text for mobile
            $(".current-pos").html(value);
        },
        openMenu : function(e){
            // open mobile menu
            var temp = sBar.checkLife() ? sBar.getSbHeight() : 0;
            $('.current-pos').fadeOut(100);
            $('.mobile-section-navigation #section-nav-next').fadeOut(100);
            $('.mobile-section-navigation #section-nav-prev').fadeOut(100);
            $('.section-navigation-list').css('height',$(window).height() - (temp + fixedTracking.getOffset('top')));
            $('.section-navigation-list').addClass('abbv-active');
            $('.mobile-section-navigation #section-nav-menu').removeClass(openIcon).addClass(closeIcon);
            freezePage(true);
        },
        closeMenu : function($target){
            // close mobile menu
            freezePage(false);
            $('.current-pos').fadeIn();
            $('.mobile-section-navigation #section-nav-next').fadeIn();
            $('.mobile-section-navigation #section-nav-prev').fadeIn();
            $('.section-navigation-list').css('height','');
            $('.section-navigation-list').removeClass('abbv-active');
            $('.mobile-section-navigation #section-nav-menu').removeClass(closeIcon).addClass(openIcon);
            if($target != undefined){
                let temp = $target.offset().top;
                $('body, html').animate({scrollTop: temp - fixedTracking.getOffset('top') }, 'slow');
                // setTimeout(function(){
                //     abbvSectionNav.checkSection();
                // },2000);
            }
        },
        printObj : function(){
            console.log(sections);
            console.log($activeSection);
            console.log(openIcon);
            console.log(closeIcon);
        }
    }
})();
$(document).ready(function() {
    sResults.initialize();
    var regex = /^[a-zA-Z0-9@]/;
    // Listener to trigger search on click of search icon in the search box
    $('.abbv-search-results .abbv-search-navigation i').on('click',function(){
        var listIndex = $('.abbv-search-results .abbv-search-suggestions').find('li.selected').index();
        if(listIndex >= 0 && regex.test($(this).next('input').val())) {
            sessionStorage.setItem('AnlyticalTermType','Suggestion');
            sessionStorage.setItem('AutoPosition',listIndex.toString());
            sResults.update($(this).next('input').val());
        } else if(regex.test($(this).next('input').val())){
            //Update search analytics properties on select typed
            sessionStorage.setItem('AnlyticalTermType','Typed');
            sResults.update($(this).next('input').val());
        }
    });
    // Listener to trigger search on press of enter
    //Update search analytics properties on select Typed
    var isArrowkey = false;
    var listSelectedIndex = 0;
    $('.abbv-search-results .abbv-search-navigation input').on('keyup',function(e){
        if(e.which == 40 || e.which == 38) { 
            setTimeout(function(){
                listSelectedIndex = $('.abbv-search-results .abbv-search-suggestions').find('li.selected').index();
            },10);
            isArrowkey = true;
        } else if(e.which != 13) {
            isArrowkey = false;
        }
        if(e.which == 13 && validateSearch($(this).val())) {
            if(isArrowkey){
                sessionStorage.setItem('AnlyticalTermType','Suggestion');
                sessionStorage.setItem('AutoPosition',listSelectedIndex.toString());
                isArrowkey = false;                
            } else {
                sessionStorage.setItem('AnlyticalTermType','Typed');
            }
            sResults.clearResults();
            sResults.update($(this).val());
            $(this).next(".abbv-search-suggestions").hide();
        }
    });

    // Listener for when the user clicks on a suggested search from dropdown
    $('.abbv-search-results .abbv-search-suggestions').on('click','a', function(e){
        e.preventDefault();
        var listIndex = $(this).parent().index();
        //Update search analytics properties on select suggestion list
        sessionStorage.setItem('AnlyticalTermType','Suggestion');
        sessionStorage.setItem('AutoPosition',listIndex.toString());        
        sResults.update($(this).html());        
    });
    
    // Listener for when the user clicks on a search results
    $(document).on('click','.abbv-card-text-content a', function(e) {
        e.preventDefault();
        var clickLink    = $(this).attr('href');
        var clickIndex   = $(this).parents('.abbv-col').index();
        var clickTitle   = $(this).attr('title');        
        var clickPageNum = $('.abbv-paging-controls-container').find('a.active').text();
        var searchClick  = {
            'Clicklink': decodeURIComponent(clickLink),
            'Clickindex': clickIndex.toString(),
            'Clicktitle': clickTitle,
            'Clickpagenum' : clickPageNum
        };
        sessionStorage.setItem('Searchclick', JSON.stringify(searchClick));
        window.location = clickLink;
    });

    var clickObj = JSON.parse(sessionStorage.getItem('Searchclick'));
    if(clickObj && $('.abbv-search-results').length != 0) {
        abbvDigitalData.search({clickTitle: '',clickLink: '',clickPageNum:'',clickPosition:''});
        sessionStorage.removeItem('Searchclick')
    }

});
// Search Result Object
var sResults = (function(){
    var resultsObj,
        paginationObj,
        perPage,
        searchQuery,
        topPos;
    return{
        // Sets up-intializes results object. If query is present in URI get the results
        initialize: function(){
            resultsObj = $('.abbv-search-results-content');
            paginationObj = $('.abbv-paging-numbers ul');
            perPage = resultsObj.attr('data-per-page');
            searchQuery = urlObj.getParam('q');
            topPos = $('#searchTerm')[0] ? $('#searchTerm').offset().top - fixedTracking.getOffset('top',$('#searchTerm').offset().top) : 0;            
            if(searchQuery !== 'undefined'){sResults.getResults(searchQuery);}
        },
        // Clears search box if query is not empty get new results
        update: function(query){
            $('.abbv-search').val('');
            searchQuery = query;
            if(searchQuery !== 'undefined'){sResults.getResults(searchQuery);}
        },
        // Clears out results and appends loading animation
        clearResults: function(){
            resultsObj.empty();
            resultsObj.append('<div class="abbv-animation-loading"></div>');
        },
        // Gets results for corresponding query
        getResults: function(query, pageNum){
            // if no page number defined load first page
            var page = typeof pageNum == 'undefined' ? 1 : pageNum;
            var pageOrgin = (sessionStorage.getItem('OriginTitle')) ? decodeURIComponent(sessionStorage.getItem('OriginTitle')) : '';
            var pageURL = (document.referrer == "") ? decodeURIComponent(window.location) : decodeURIComponent(document.referrer);
            var queryTerm = decodeURIComponent(query); 
           
            if(AbbViePageInfo.apiEndPoints.getSearchResults != "") {
                //var _url = '/admp-common-elements/common-elements-aem-parent/ui.apps/src/main/content/jcr_root/apps/common-elements/v1/components/content/search-results/ui/data/searchResults.json';               
                var _url = AbbViePageInfo.apiEndPoints.getSearchResults + '?q='+query+'&sp_c='+perPage+'&page='+page;                 
                ajaxCall(_url, "GET", "", onSucessSearch, onFailedSearch, true);
            } else {
                console.warn("getSearchResults url not defined");
            }
                        
            // On successfully get the search results
            function onSucessSearch(data) {
                // Unhide the labels and loading gif
                $('.abbv-search-results').removeClass('hideLabels');
                // If no results for search clear labels and append "No Results"
                if(data.general.total == "0"){
                    sResults.hideLabels();
                    resultsObj.empty();
                    resultsObj.append('<div class="abbv-col abbv-col-12"><div class="abbv-card"><div class="abbv-card-text-content-container"><div class="abbv-card-text-content"><p>No results found.</p></div></div></div></div>');
                    abbvDigitalData.search({count: ''});
                }
                else{
                    sResults.showLabels();
                    sResults.updatePagination(data);
                    resultsObj.empty();

                    var results = data.resultsets[0].results;                     
                    for (var i = 0; i <= results.length - 1; i++) {
                        resultsObj.append('<div class="abbv-col abbv-col-12"><div class="abbv-card"><div class="abbv-card-text-content-container"><div class="abbv-card-text-content"><a href="'+results[i].link+'" title="'+results[i].title+'"><h3>'+results[i].title+'</h3></a><p>'+results[i].desc+'</p></div></div></div></div>');
                    }
                    //Update search analytics properties after search results                      
                    abbvDigitalData.search({count: data.general.total});
                }
                window.history.pushState("", "", '?q='+data.general.q);
                safetyBarScrollCheck();
            }

            // On failed getting search results
            function onFailedSearch(data, textStatus, error) {
                console.error("getJSON failed, status: " + textStatus + ", error: "+error);
                sResults.hideLabels();
                resultsObj.empty();
                resultsObj.append('<div class="abbv-col abbv-col-12"><div class="abbv-card"><div class="abbv-card-text-content-container"><div class="abbv-card-text-content"><p>No results found.</p></div></div></div></div>');
                abbvDigitalData.search({count:''});
                window.history.pushState("", "", '?q='+data.general.q);
            }

            abbvDigitalData.search({
                term: queryTerm, 
                origin: pageOrgin, 
                originURL: pageURL, 
                type: sessionStorage.getItem('AnlyticalTermType'), 
                autoPosition: sessionStorage.getItem('AutoPosition')
            });

        },
        // Builds and updates pagination dynamically on returned results
        updatePagination: function(data){
            var paginationData = data.pagination[0];
            var values = {
                searchTerm: data.general.q,
                rangeLower: data.general.page_lower,
                rangeUpper: data.general.page_upper,
                totalResults: data.general.total
            };
            var textLine1 = $('#searchTerm').attr('data-structure').replace(/\{\{([^}]+)\}\}/g, function(i, match) {
                return values[match];});
            var textLine2 = $('#dataRange').attr('data-structure').replace(/\{\{([^}]+)\}\}/g, function(i, match) {
                return values[match];});
            // Inject Search Term
            $('#searchTerm').empty().append(textLine1);
            // Inject range viewing 
            $('#dataRange').empty().append(textLine2);
            paginationObj.empty();
            var styleClass = "";
            var isFirst = (paginationData.previous == "") ? 'inactive' : '';
            var isLast = (paginationData.next == "") ? 'inactive' : '';
            paginationObj.addClass('expanded-control').removeClass('standard');
            paginationObj.append('<li id="firstPage"><a class="'+isFirst+'" data-link="#" title="First page"><i></i></a></li><li id="previousPage"><a class="'+isFirst+'" data-link="'+paginationData.previous+'" title="Previous page"><i></i></a></li>');
            for (var i = 0; i <= paginationData.pages.length -1; i++) {
                // populate number area
                if(paginationData.pages[i].selected == "true"){styleClass = 'active';} else{ styleClass = "";}
                paginationObj.append('<li><a class="'+styleClass+'" href="javascript:void(0)" data-link="'+paginationData.pages[i].link+'" title="Page '+paginationData.pages[i].page+'">'+paginationData.pages[i].page+'</a></li>')
            }
            paginationObj.append('<li id="nextPage"><a class="'+isLast+'" data-link="'+paginationData.next+'" title="Next page"><i></i></a></li><li id="lastPage"><a class="'+isLast+'" data-link="'+paginationData.last+'" title="Last page"><i></i></a></li>');
           
            $('.abbv-paging-numbers ul li a').on('click',function(e){
                e.preventDefault();
                var temp = this.dataset.link.split('page=');
                var getPage = (temp.length < 2) ? 1 : temp[1].split(';')[0];
                sResults.getResults(searchQuery,getPage);
                $("html, body").animate({ scrollTop: topPos }, "medium");
                return false;
            });
        },
        // Hides result labels like "showing results for.."
        hideLabels: function(){
            $('.abbv-paging-controls-container').hide();
            $('#searchTerm').hide();
            $('.abbv-search-results-number').hide();
            $('.abbv-animation-loading').hide();
        },
        showLabels: function(){
            $('.abbv-paging-controls-container').show();
            $('#searchTerm').show();
            $('.abbv-search-results-number').show();
        }
    };
})();

// AbbVie Safety Bar Component
$(document).ready(function () {
    // Check Cookie
    var safetyBarMore = cookieObj.getCookie('admp_safety_bar');
    // if (safetyBarCookie == 1) { safetyBarMore = 1; } else { safetyBarMore = 0; }

    // Initial Safety Bar State
    if (safetyBarMore == 1) {
        // Cookie Exists - Less Content
        $(".abbv-safety-bar-less").show();
        $(".abbv-safety-bar-more").hide();
    } else {
        // Cookie Void - More Content
        $(".abbv-safety-bar-less").hide();
        $(".abbv-safety-bar-more").show();
    }

    // Maximize Safety Bar
    $(".abbv-safety-bar").on('click', function () {
        if (!$('.abbv-brand-explorer').length == 0) { closeBrandExplorer(); }
        maximizeSafety(safetyBarMore);
        freezePage(true);
        activateDimmer('minimizeSafety');
    });

    // Minimize Safety Bar
    $(".abbv-safety-bar-button-minus").click(function (e) {
        e.stopPropagation();
        deactivateDimmer();
        freezePage(false);
    });

    // Hide / Show Safety Bar on Scroll
    if (sBar.checkLife()) {
        if (!$(".abbv-isi-content").length == 0) {
            //On Load perform safetyBarScrollCheck
            safetyBarScrollCheck();

            //On scroll perform safetyBarScrollCheck
            $(window).on('scroll', safetyBarScrollCheck);
            sBar.updateSbVar();
        }
        else { console.warn('Class "abbv-isi-content" must be added to the on page safety information block'); }
    }
    if (urlObj.getParam('ISI') == "1") {
        maximizeSafety(safetyBarMore);
        freezePage(true);
        activateDimmer('minimizeSafety');
    }
    $('.safety-bar-more,.abbv-safety-bar-less').on('touchmove', function (e) { e.preventDefault(); })

});

// Throttled Safety bar fade out/fade in check for scrolling
var safetyBarScrollCheck = throttle(function () {
    var abbvSafetyBarHideShow = $(".abbv-isi-content").offset().top;
    if ($(window).scrollTop() + $(window).height() > abbvSafetyBarHideShow + 200) {
        $(".abbv-safety-bar").fadeOut(400);
    } else {
        $(".abbv-safety-bar").fadeIn(400);
    }
}, 200);

function maximizeSafety(cookie) {
    $(".abbv-safety-bar").addClass("abbv-safety-bar-maximized");
    $(".abbv-safety-bar-fade").fadeOut(400);
    $(".abbv-safety-bar-content").hide();
    $(".abbv-safety-bar-content-maximized").show();
    $(".abbv-safety-bar-button-plus").hide();
    $(".abbv-safety-bar-button-minus").show();
    if (cookie != 1) {
        // Set Cookie If Void
        cookieObj.createCookie('admp_safety_bar', '1', 365);
    }
    $(".abbv-safety-bar").off('click');
}
function minimizeSafety() {
    freezePage(false);
    $(".abbv-safety-bar").removeClass("abbv-safety-bar-maximized");
    $(".abbv-safety-bar-fade").delay(1).fadeIn(400);
    $(".abbv-safety-bar-content").hide();
    var cookie = cookieObj.getCookie('admp_safety_bar');
    if (cookie == 1) {
        // Cookie Exists - Less Content
        $(".abbv-safety-bar-less").show();
        $(".abbv-safety-bar-more").hide();
    } else {
        // Cookie Void - More Content
        $(".abbv-safety-bar-less").hide();
        $(".abbv-safety-bar-more").show();
    }
    $(".abbv-safety-bar-button-minus").hide();
    $(".abbv-safety-bar-button-plus").show();
    $(".abbv-safety-bar").css('height', '');
    $(".abbv-safety-bar").on('click', function () {
        if (!$('.abbv-brand-explorer').length == 0) { closeBrandExplorer(true); }
        maximizeSafety(cookieObj.getCookie('admp_safety_bar'));
        freezePage(true);
        activateDimmer('minimizeSafety');
    });
}
$(document).ready(function(){
	$('.abbv-quick-poll').each(function(){
		var cookieCheck = cookieObj.getCookie($(this).attr('data-pollID'));
		if(cookieCheck == 1) {
			if($(this).attr('data-get-api') == "true"){buildPoll($(this));} 
			handleAggrRequest($(this).children('.ia-area'),$(this).attr('data-masterID'));
		} else {
			if(this.dataset.getApi == "true"){ 
				$(this).find('.loading').fadeIn();
				buildPoll($(this)); 
			}
		}
	});
	$('.abbv-quick-poll .main-error button').on('click',function(){
		var $qPollObj = $(this).closest('.abbv-quick-poll');
		$qPollObj.find('.main-error').removeClass('abbv-active');
		$qPollObj.find('.main-error span').empty();
		$qPollObj.find('.loading').hide();
		$qPollObj.find('.loading .abbv-animation-loading').show();
	});
	$('.qPoll-option').on('click',function(){
		var $that = $(this);
		sendAnswer($(this).closest('.abbv-quick-poll'),$(this),function(){handleAggrRequest($that.closest('.ia-area'),$that.closest('.abbv-quick-poll').attr('data-masterID'));});
	});
});

function throwAPIError(obj, errName){
	obj.find('.abbv-animation-loading').hide();
	var target = obj.find('.main-error span');
	target.empty();
	target.text(target.attr(errName));
	obj.find('.main-error').addClass('abbv-active');
}

function buildPoll(qPoll_obj){
	if (AbbViePageInfo.apiEndPoints.getAssessment != ""){
		var masterID = qPoll_obj.attr('data-masterID');
		var questID = qPoll_obj.find('.abbv-question').attr('data-questionID');
    var getPoll_URL =  AbbViePageInfo.apiEndPoints.getAssessment+"?CampaignMasterId="+masterID+"&QuesId="+questID;

      ajaxCall(getPoll_URL, "GET", "", onSucessGetPoll, onFailedGetPoll, true);

      function onSucessGetPoll(data){
			// console.log("Successful GET ** Build");
			if(data.IsStatusSuccessful){
				// console.log('GET -- successful build');
				var quesNum;
				for(let j = 0; j < data.ContentResult.AssessmentQuestion.length; j++){
					if(data.ContentResult.AssessmentQuestion[j].QuestionId == questID){ quesNum = j;}
				}
				if(quesNum != undefined){
					var qOptions = data.ContentResult.AssessmentQuestion[quesNum].QuestionOption;
					for(let i = 0; i < qOptions.length; i++){
						let tempQ = '<button class="qPoll-option abbv-button-tertiary" data-optionID="'+qOptions[i].OptionId+'">'+qOptions[i].OptionText+'</button>';
						qPoll_obj.find('.qPoll-options').append(tempQ);
						let tempA = '<div class="option"><span></span><p>'+qOptions[i].OptionText+'</p></div>';
						qPoll_obj.find('.resultSet').append(tempA);
					}
					qPoll_obj.find('.question-container .abbv-question').text(data.ContentResult.AssessmentQuestion[quesNum].QuestionText);
					qPoll_obj.find('.loading').fadeOut();
				} else {
					throwAPIError(qPoll_obj,"data-err-no-poll");
				}
			} else {
				throwAPIError(qPoll_obj,"data-err-no-poll");
				// console.log('GET -- not successful build');
			}
		}
    function onFailedGetPoll(jqXHR, textStatus, errorThrown){     
			// console.log("Failed to get Poll Data");
			if(textStatus == "timeout"){ 
				throwAPIError(qPoll_obj,"data-err-timeout"); 
			} else { throwAPIError(qPoll_obj,"data-err-no-poll");}
    }
	} else {console.warn("getAssessment url not defined");}
}
function buildPayload(qPoll_obj, qPoll_ans){
	var payload =
	{
	   	"CampaignMasterId":qPoll_obj.attr('data-masterID'),
	   	"CompleteDate":null,
	   	"ConsumerId":"",
	   	"IndividualId":"",
	   	"AssessmentQuestion": [{
	   		"QuestionId":qPoll_obj.find('.abbv-question').attr('data-questionID'),
	   		"QuestionOptions":[{
	   			"OptionId":qPoll_ans.attr('data-optionID'),
	   			"ResponseText":""
	   		}]
	   	}],
	   	"OtherInformation":{
	   		"cid":""
	   	}
	};
	return JSON.stringify(payload);
}
function sendAnswer(qPoll_obj, qPoll_ans, callBack){
	if(AbbViePageInfo.apiEndPoints.saveAssessment != "") {
		qPoll_obj.find('.loading').show();
		var payload = buildPayload(qPoll_obj,qPoll_ans);
    var sendAnswer_URL = AbbViePageInfo.apiEndPoints.saveAssessment;

    ajaxCall(sendAnswer_URL, "POST", payload, onSucessSendAns, onFailedSendAns, true);
    function onSucessSendAns(data) {
      if(data.IsStatusSuccessful){
				console.log('Save -- successful');
				callBack();
			} else {
				console.log('Save -- not successful');
				throwAPIError(qPoll_obj,"data-err-save-poll"); 
			}
    }
    function onFailedSendAns() {
      console.log("Failed to send answers");
			throwAPIError(qPoll_obj,"data-err-save-poll"); 
    }
	} else { console.warn("saveAssessment url not defined");}
}
function handleAggrRequest(qPoll_iaArea, masterID){
	if(AbbViePageInfo.apiEndPoints.getAggregated != "") {
    var getAgg_URL = AbbViePageInfo.apiEndPoints.getAggregated+"?CampaignMasterId="+masterID;
		qPoll_iaArea.children('.loading').show();
		// var getAgg_data_call = $.ajax(getAggregateData_options);
    ajaxCall(getAgg_URL, "GET", "", onSucessGetAgg, onFailedGetAgg, true);
    function onSucessGetAgg(data) {
      var $answerAr = qPoll_iaArea.children('.answer');
			if(data.IsStatusSuccessful){
				// console.log('Get Aggregated -- successful');
				qPoll_iaArea.children('.question-container').hide();
				if(qPoll_iaArea.closest('.abbv-quick-poll').attr('data-get-api') == "true"){ $answerAr.children('.abbv-question').text(data.ContentResult.AssessmentQuestion[0].QuestionText); }
				var options = data.ContentResult.AssessmentQuestion[0].QuestionOption;
				var resultList = qPoll_iaArea.find('.option');
				for(let i = 0; i < options.length; i++){
					if(qPoll_iaArea.closest('.abbv-quick-poll').attr('data-get-api') == "true"){$(resultList[i]).children('p').text(options[i].OptionValue); }
					$(resultList[i]).children('span').text(Math.round(parseFloat(options[i].PercentageOfUsersRespondedOnOption)));
				}
				$answerAr.fadeIn();
				qPoll_iaArea.children('.loading').fadeOut();
				var cookie = qPoll_iaArea.closest('.abbv-quick-poll').attr('data-pollID');
				if(cookieObj.getCookie(cookie) != 1) {
					// Set Cookie If Void
					cookieObj.createCookie(cookie,'1',365);
				}
			} else {
				// console.log('Get Aggregated -- not successful');
				throwAPIError(qPoll_iaArea.closest('.abbv-quick-poll'),"data-err-fetch-results");
			}
    }
    function onFailedGetAgg(jqXHR, textStatus, errorThrown) {
      if(textStatus == "timeout"){ 
				throwAPIError(qPoll_iaArea.closest('.abbv-quick-poll'),"data-err-timeout");
				// console.log('Get Aggregated Data -- timeout'); 
			} else { throwAPIError(qPoll_iaArea.closest('.abbv-quick-poll'),"data-err-fetch-results");}
    }
	} else { console.warn("getAggregated url not defined");}
}

// AbbVie Drawer
$(document).ready(function () {
    // Initiate drawer
    abbvDrawer.init();

    //Open the promo drawer on click the title
    $('.abbv-promo-drawer-handle').on('click', function () {
        if ($('.abbv-promo-drawer').length) { abbvDrawer.toggleDrawer(); }
    });
    //Close the promo drawer on click close btn
    $('#abbv-promo-drawer-close').on('click', function () {
        if ($('.abbv-promo-drawer').length) { abbvDrawer.closeDrawer(); }
    });
  
});

var abbvDrawer = (function () {
    let $abbvPromoDrawer;
    let $abbvPromoDrawerHandle;
    let $abbvPromoDrawerTitle;
    let $abbvPromoDrawerContent;
    let $abbvPromoDrawerDesc;
    let sBar_height;
    let promoDrawer_pos;
    let isDrawerViewed_cookie;
    let drawer_id;
    let drawer_view_once;
    let drawerContentMaxHeight;

    return {
        init: function () {
            $abbvPromoDrawer = $('.abbv-promo-drawer');
            $abbvPromoDrawerHandle = $('.abbv-promo-drawer-handle');
            $abbvPromoDrawerTitle = $('.abbv-promo-drawer-title');
            $abbvPromoDrawerContent = $('.abbv-promo-drawer-content');
            $abbvPromoDrawerDesc = $('.abbv-promo-drawer-description');
            drawer_id = $abbvPromoDrawer.attr('data-id');
            drawer_view_once = $abbvPromoDrawer.attr('data-view-once') || "false";
            promoDrawer_pos = $abbvPromoDrawer.css('bottom');
            isDrawerViewed_cookie = cookieObj.getCookie(drawer_id);
            if ($abbvPromoDrawer.length) { this.showDrawer() }
        },
        toggleDrawer: function () {
            $abbvPromoDrawer.toggleClass('abbv-active');
            $abbvPromoDrawer.animate()
        },
        closeDrawer: function () {
            $abbvPromoDrawer.removeClass('abbv-active');
            //Set cookiee if promo drawer is not viewed
            if (!$abbvPromoDrawer.hasClass('promo-viewed')) {
                this.setCookie();
            }
        },
        showDrawer: function () {
            this.positionDrawer();
            //Set promo-viewed class to drawer if cookie is available
            if (isDrawerViewed_cookie == 1) {
                $abbvPromoDrawer.addClass('promo-viewed');
                if(drawer_view_once !== "true"){
                    $('.abbv-promo-drawer').addClass('show-promo-drawer');
                }
            } else {
                $('.abbv-promo-drawer').addClass('show-promo-drawer');
            }
        },
        positionDrawer: function () {
            let drawerBottomPos;
            let setDrawerPos = function () {
                // check if the safety bar is present and store in variable
                if (sBar.checkLife() && $('.abbv-safety-bar').is(':visible')) {
                    sBar.updateSbVar(); sBar_height = sBar.getSbHeight();
                }
                // else set variable to 0
                else { sBar_height = 0; }
                drawerBottomPos = (sBar_height !== 0) ? sBar_height + 20 : promoDrawer_pos;
                $abbvPromoDrawer.css({ 'bottom': drawerBottomPos })
            }

            //Set max-height for drawer content 
            let setDrawerMaxHeight = function () {
                drawerContentMaxHeight = $(window).height() - (sBar_height + 50);
                $abbvPromoDrawerContent.css({ 'max-height': drawerContentMaxHeight });

                //Move the close btn to right if scroll presents in the content
                let drawerCloseRightPos = ($abbvPromoDrawerDesc.outerHeight() < $abbvPromoDrawerDesc[0].scrollHeight) ? 15 : 0
                if ($('#abbv-promo-drawer-close').length) { $('#abbv-promo-drawer-close').css({ 'right': drawerCloseRightPos }); }
            }

            setTimeout(setDrawerPos, 50);
            setTimeout(setDrawerMaxHeight, 50);
            $(window).on("resize", debounce(setDrawerMaxHeight, 100));
            if (sBar_height !== 0) {
                $(window).on("scroll", throttle(setDrawerPos, 100));
                $(window).on("resize", debounce(setDrawerPos, 100));
            }
            //To avoid time lag on visibility 
            if ($abbvPromoDrawer.length) { $abbvPromoDrawer.css('opacity', '1') }
            this.setHandleHeight();
        },

        setCookie: function () {
            if (isDrawerViewed_cookie != 1) {
                cookieObj.createCookie(drawer_id, '1', 365);
                $abbvPromoDrawer.addClass('promo-viewed');
            }
        },

        setHandleHeight: function () {
            let drawerTitleWidth = $abbvPromoDrawerTitle.outerWidth();
            let drawerhandleHeight = $abbvPromoDrawerHandle.outerHeight();

            //set handle height when drawer title width exceeds handle height
            if (drawerTitleWidth > drawerhandleHeight) { $abbvPromoDrawerHandle.height(drawerTitleWidth); drawerhandleHeight = drawerTitleWidth }

            //set max-height for drawer content if drawer handle exceeds content height
            setTimeout(function () {
                if (drawerhandleHeight > drawerContentMaxHeight) { $abbvPromoDrawerContent.css({ 'max-height': drawerhandleHeight + 25 }) }
            }, 50)
        }
    };
})();
// Document Ready
$(document).ready(function() {
    // Open modal (Url # with Modal ID) 
    abbvModal.initDeepLinkModal();
    // Open Modal (Active Listener) 
    $(document).on('click','.abbv-modal-open', function(e){
         e.preventDefault();
         abbvModal.openModal(this);
         activateDimmer('abbvModal.closeModal');
    });
    // Added listener to open modal inside active modal 
    $('.abbv-modal-content').on('click', '.abbv-modal-open', function(e){
        console.log('modal clicked');
        e.preventDefault();
        var _this = this;
        if ($('.abbv-modal.abbv-active').length) {
            abbvModal.closeModal(function(){
                abbvModal.openModal(_this);
            });      
        }  
    });
    // Close Modal
    $(".abbv-modal-close,.abbv-modal-close-inline").click(function() { 
        abbvModal.closeModal();
        deactivateDimmer();
    });
    $(document).keyup(function(e) { 
        if (e.keyCode === 27) { 
            $(".abbv-modal.abbv-active").stop().fadeOut(400).css('z-index', '');
            if(!sBar.isMaxed()){deactivateDimmer();freezePage(false);}
        } 
    });
    $('.abbv-modal.image-modal').find('img').each(function(){
        var imgClass = (this.width / this.height > 1) ? 'image-modal-wide' : 'image-modal-tall';
        $(this).parents('.abbv-modal.image-modal').addClass(imgClass);
    });
    $(".abbv-modal-content").click(function(e) { e.stopPropagation(); });
});
var abbvModal = (function() {
    return{
        initDeepLinkModal: function () {
            if (window.location.hash) {
                var urlHash = window.location.hash.substr(1);
                var hashElement = $("." + urlHash);
                if(hashElement.hasClass("abbv-modal")) {
                    this.openModal(hashElement, 'hashTrigger');
                    activateDimmer('abbvModal.closeModal');
                }
            }
        },
        openModal: function (modal, triggerFrom) {
            let $modalTrigger = $(modal);
            // Check Deep link modal/Button modal
            let $modal = (triggerFrom !== 'hashTrigger') ? $("." + $modalTrigger.attr("data-id")) : $(modal);
            // If modal is an exit modal
            if($modalTrigger.hasClass('abbv-exit-modal')){
                $modal.find('a').attr('href',$modalTrigger.attr('data-href'));
            }
            // If modal is opened from ISI
            if(sBar.isMaxed()){ 
                $modal.fadeTo(500,1).css('z-index', 502);
            } else{
                var touchAdjust = touchDevice() ? .98 : .9;
                setTimeout(function(){$('.abbv-modal').css('max-height', (window.innerHeight*touchAdjust - (sBar.getSbHeight() + 10)));},300);
                // $('.abbv-modal').css('max-height', (window.innerHeight - (sBar.getSbHeight() + 10 + touchAdjust)));
                $modal.delay(2).fadeTo(500,1);
                freezePage(true);
            }
            // Ajax (data-url)
            if($modalTrigger.attr("data-url")) {
                $modal.find('.abbv-modal-content').load($modalTrigger.attr("data-url")); 
            } else {
                $(".abbv-animation-loading").hide();
            }
            
            // Integration with videos
            // Pause on Modal open
            if($('.video-js').length != 0){
                for(var i = 0; i < Object.keys(videojs.players).length; i++){
                    videojs.getPlayer(Object.keys(videojs.players)[i]).pause();
                }
            }

            if($modal.find('.video-js').length != 0){
                var videoModal = $modal.find('.video-js');
                var vid = videoModal.attr('id');
                if($modal.find('.abbv-carousel').length) {
                    var carouselObject = $modal.find('.abbv-carousel');
                    initScrollButtons(carouselObject); 
                }
                videojs(vid).autoplay('muted');
                //auto play working only in 'muted' option
            }
            
            if($modal.find('.abbv-img-slider').length != 0){
                $($modal.find('.abbv-img-slider')).each(function(){ initSlider(this);});
            }
            $modal.addClass('abbv-active');            
        },
        closeModal : function(callback){          
            var vid = $('.abbv-modal.abbv-active').find('.video-js');
            if(vid.length > 0){videojs(vid.attr('id')).pause();}
            $(".abbv-modal.abbv-active").stop().fadeOut(400, callback).css('z-index', '').removeClass('abbv-active');
            if(!sBar.isMaxed()){freezePage(false);}
        }

    };
})();

// Document Ready
$(document).ready(function() {
	$('.image-hover').each(function(){$(this).zoom();});
	$('.image-drag').each(function(){$(this).zoom({ on:'grab' });});
});
$(document).ready(function(){
    // Check for previous answer
    $('.abbv-info-tree').each(function(){
        var cookieValue = abbvGetCookie(encodeURIComponent($(this).attr('data-qPollID')));
        if(cookieValue != null ) {
			var decodedCookie= decodeURI(cookieValue);		
            $(this).find('.multistep-qPoll-btn').hide();
            $(this).find('.multistep-qPoll-results[data-answer-id="' + decodedCookie + '"]').show();
        } else {
            $(this).find('.multistep-qPoll-btn').show();
            $(this).find(".multistep-qPoll-results").hide();
        }
    });

    $('.multistep-qPoll-option').on('click',function(){
        var cookieCheck = $(this).closest('.abbv-info-tree').attr('data-qpollid');
        var cookieValue = $(this).attr('data-question-id');
        cookieObj.createCookie(cookieCheck,cookieValue,365);
        $(this).closest('.multistep-qPoll-options').find('.multistep-qPoll-results[data-answer-id="' + cookieValue + '"]').show();
        $(this).parent(".multistep-qPoll-btn").hide();
    })
});


// Call & init all sliders
$(document).ready(function() {
  $('.abbv-img-slider').each(function(){ setTimeout(initSlider(this),2000);});
  // Update sliders on resize. 
  $(window).on('resize',adjustSliderSize);
});

var adjustSliderSize = debounce(function() {
  $('.abbv-img-slider').each(function(){
    initSlider(this);
  });
},200);

function dragsW(dragElement, resizeElement, container) {
  
  var minLeft,
      maxLeft,
      leftValue,
      widthValue;

  // Initialize the dragging event on mousedown.
  dragElement.on('mousedown touchstart', function(e) {
    
    dragElement.addClass('draggable');
    resizeElement.addClass('resizable');
    
    // Check if it's a mouse or touch event and pass along the correct value
    var startX = (e.pageX) ? e.pageX : e.originalEvent.touches[0].pageX;
    
    // Get the initial position
    var dragWidth = dragElement.outerWidth(),
        posX = dragElement.offset().left + dragWidth - startX,
        containerOffset = container.offset().left,
        containerWidth = container.outerWidth();
 
    // Set limits
    minLeft = containerOffset;
    maxLeft = containerOffset + containerWidth - dragWidth;
    
    // Calculate the dragging distance on mousemove.
    dragElement.parents().on("mousemove touchmove", function(e) {
      // Check if it's a mouse or touch event and pass along the correct value
      var moveX = (e.pageX || e.pageX == 0) ? e.pageX : e.originalEvent.touches[0].pageX;
      
      leftValue = moveX + posX - dragWidth;
      
      // Prevent going off limits
      if ( leftValue < minLeft) {
        leftValue = minLeft;
      } else if (leftValue > maxLeft) {
        leftValue = maxLeft;
      }
      
      // Translate the handle's left value to masked divs width.
      widthValue = (leftValue + dragWidth/2 - containerOffset)*100/containerWidth+'%';
            
      // Set the new values for the slider and the handle. 
      // Bind mouseup events to stop dragging.
      $('.draggable').css('left', widthValue).on('mouseup touchend touchcancel', function () {
        $(this).removeClass('draggable');
        resizeElement.removeClass('resizable');
      });
      $('.resizable').css('width', widthValue);
    }).on('mouseup touchend touchcancel', function(){
      dragElement.removeClass('draggable');
      resizeElement.removeClass('resizable');
      dragElement.parents().off("mousemove touchmove");
    });
    e.preventDefault();
  }).on('mouseup touchend touchcancel', function(e){
    dragElement.removeClass('draggable');
    resizeElement.removeClass('resizable');
  });
}

function dragsH(dragElement, resizeElement, container) {

  var minTop,
      maxTop,
      topValue,
      heightValue;

  // Initialize the dragging event on mousedown.
  dragElement.on('mousedown touchstart', function(e) {
    
    dragElement.addClass('draggableH');
    resizeElement.addClass('resizableH');
    
    // Check if it's a mouse or touch event and pass along the correct value
    var startY = (e.pageY) ? e.pageY : e.originalEvent.touches[0].pageY;
    
    // Get the initial position
    var dragHeight = dragElement.outerHeight(),
        posY = dragElement.offset().top + dragHeight - startY,
        containerOffset = container.offset().top,
        containerHeight = container.outerHeight();
 
    // Set limits
    minTop = containerOffset;
    maxTop = containerOffset + containerHeight - dragHeight;
    
    // Calculate the dragging distance on mousemove.
    dragElement.parents().on("mousemove touchmove", function(e) {
        
      // Check if it's a mouse or touch event and pass along the correct value
      var moveY = (e.pageY || e.pageY == 0) ? e.pageY : e.originalEvent.touches[0].pageY;
      
      topValue = moveY + posY - dragHeight;
      
      // Prevent going off limits
      if ( topValue < minTop) {
        topValue = minTop;
      } else if (topValue > maxTop) {
        topValue = maxTop;
      }
      
      // Translate the handle's top value to masked divs height.
      heightValue = (topValue + dragHeight/2 - containerOffset)*100/containerHeight+'%';

      // Set the new values for the slider and the handle. 
      // Bind mouseup events to stop dragging.
      $('.draggableH').css('top', heightValue).on('mouseup touchend touchcancel', function () {
        $(this).removeClass('draggableH');
        resizeElement.removeClass('resizableH');
      });
      $('.resizableH').css('height', heightValue);
    }).on('mouseup touchend touchcancel', function(){
      dragElement.removeClass('draggableH');
      resizeElement.removeClass('resizableH');
      dragElement.parents().off("mousemove touchmove");
    });
    e.preventDefault();
  }).on('mouseup touchend touchcancel', function(e){
    dragElement.removeClass('draggableH');
    resizeElement.removeClass('resizableH');
  });
}

function initSlider(slider){
  //Remove previous listeners
  $(slider).off();
  //Define vars
  var cur = $(slider);
  var sliderAttr;
  var imgAttr;
  var width = cur.width()+'px';
  var height = cur.height()+'px';
  var switchD;
  var toDo;
  if(slider.dataset.slideDirection == "horizontal"){
    sliderAttr = "left";
    imgAttr = "width";
    switchD = width;
    toDo = dragsW;
  } else if (slider.dataset.slideDirection == "vertical"){
    sliderAttr = "top";
    imgAttr = "height";
    switchD = height;
    toDo = dragsH;
  } else { console.error('No direction set on image compare slider component'); return;}

    // Adjust the slider
    var startingP = slider.dataset.startPoint;
    cur.find('.slider-handle').css(sliderAttr, startingP);
    cur.find('.img-alt-container').css(imgAttr, startingP);
    cur.find('.img-alt-container img').css(imgAttr, switchD);
    cur.find('.img-alt-container .image-text-overlay-container').css({'width': width, 'height': height});
    // Bind dragging events
    toDo(cur.find('.slider-handle'), cur.find('.img-alt-container'), cur);
}
// AbbVie Hot Spot Component

$(document).ready(function() {
    // Open AbbVie Hot Spot Panel
    $(".abbv-hot-spot-click").click(function() {
        if($(this).next().is(":visible")) { 
            $(this).removeClass("active");
            $(this).next().fadeOut(300);
        } else {
            $(".abbv-hot-spot-panel").delay(1).fadeOut();
            $(".abbv-hot-spot-click").removeClass("active");
            $(".abbv-hot-spot-click").parent().css({"z-index":"1"});
            $(this).parent().css({"z-index":"3"});
            $(this).addClass("active");
            $(this).next().fadeIn(300);
        }        
    });
    
    // Close AbbVie Hot Spot Panel
    $(".abbv-hot-spot-panel-close").click(function() {
        $(this).parent().fadeOut(300);
        $(this).parent().prev().removeClass("active");
    });
});
// AbbVie Header Component

$(document).ready(function() {
  //Populate the user name from admp_ufln cookie
    if(cookieObj.getCookie('admp_ufln') != undefined && $('#loggedin-user-name').attr('data-welcome-text') != undefined){
        var admp_ufln = cookieObj.getCookie('admp_ufln');
        var res = admp_ufln.split("-");
        let values = {
            firstName: res[0],
            lastName:  res[1]
        };
        var loggedinUserName = $('#loggedin-user-name').attr('data-welcome-text').replace(/\{\{([^}]+)\}\}/g, function(i, match) {
            return values[match];
        });
        $('#loggedin-user-name,#loggedin-user-menu-name').empty().append(loggedinUserName);
    }

    var cookieCheck = abbvGetCookie('admp_login_token');
    if(cookieCheck != null) { $('.abbv-header').addClass('abbv-logged-in'); }
    else { $('.abbv-header').removeClass('abbv-logged-in'); }
    
    var link = $(".abbv-search-navigation a").attr("href");
    $("input.abbv-search").attr("data-results-page", link); 
    
    $('.abbv-login').on('click', function(e){
        var currentPageURL = window.location.href;
        var linkType = $(this).attr('target');
        if((currentPageURL.indexOf("/content") != -1)){
			var urlArr = currentPageURL.indexOf("/content");
            var firstPathUrl = currentPageURL.substring(0,urlArr);
            var secondPath = currentPageURL.substring(urlArr,currentPageURL.length);
            var secondPathSplit = secondPath.split("/");
            var secondPathUrl= secondPath.replace('/'+secondPathSplit[1]+'/'+secondPathSplit[2]+'/'+secondPathSplit[3],"");            
            var shortURL = firstPathUrl+secondPathUrl;
           	cookieObj.createCookie("admp_login_referrer",shortURL,1);
        }else{
            cookieObj.createCookie("admp_login_referrer",currentPageURL,1);
        }
        if(linkType == "_blank"){ window.open(this.href, linkType);}
        else{window.location.href = this.href;}
        e.preventDefault();
    })
    $('.abbv-logout').on('click', function(e){
        logoutHandler();
    })
    if(abbvIsCookiePresent('admp_login_token')){
      //  decryptResponse();
       updateToken(cookieCheck);
    }
    // Navigation drop downs
    $(".abbv-navigation > ul > li").hover(
        function(e) {
            if(!touchDeviceCheck){
                //var toDo = $(this).children('a.abbv-has-submenu').hasClass("abbv-active") ? 'removeClass' : 'addClass';
                var toDo = (e.type == 'mouseleave') ? 'removeClass' : 'addClass';
                $(this).children('a.abbv-has-submenu')[toDo]("abbv-active");
                var menuDiv = $(this).children('div.abbv-submenu');
                if(menuDiv.length != 0){
                    if(toDo == 'addClass' && e.type == 'mouseenter'){
                        menuDiv.fadeTo(300,1);
                    } else { menuDiv.stop(true,false).fadeOut(100);}
                    var off = menuDiv.offset();
                    var l = off.left;
                    var w = menuDiv.width();
                    var docH = $(window).height();
                    var docW = $(window).width();
                    
                    var isEntirelyVisible = (l + w <= docW);
                    if(!isEntirelyVisible){
                        menuDiv.addClass('off-right');
                    }
                }
                e.preventDefault();
            }
        }).on('click',function(e){
            if(touchDeviceCheck){
                var toDo = $(this).children('a.abbv-has-submenu').hasClass("abbv-active") ? 'removeClass' : 'addClass';
                $(this).children('a.abbv-has-submenu')[toDo]("abbv-active");
                $(this).children('div.abbv-submenu').stop(true,false).fadeToggle(200);
                // e.preventDefault();
            }        
        }
    );

    // Search
    $(".abbv-search-toggle").on("click", function(){
        $('.abbv-buddy button.abbv-active').each(function(){$(this).click(); });
        var that = this;
        var thatIcon = $(that).children('i');
        var swapIn = '';
        if(!$(that).hasClass('active')){ 
            swapIn = 'close'; 
            $(that).addClass('active');
            $(".abbv-search-navigation").addClass("abbv-search-active");
        } else{ 
            swapIn = 'search'; 
            $(that).removeClass('active');
            $(".abbv-search-navigation").removeClass("abbv-search-active");
        }
        $(thatIcon).hide().removeClass(function (index, className) {
            return (className.match (/(^|\s)abbv-icon\S+/g) || []).join(' ');
        }).addClass('abbv-icon-'+swapIn).fadeIn(300);
        $(".abbv-search").focus();
    });
        
    // Suggest
    $('.abbv-search').on('click keyup', function(e) { 
        if(this.dataset.suggestToggle == "no") return;
        var maxSuggestions = this.dataset.maxSuggestions;
        var charTrigger = this.dataset.charTrigger;
        var usedArrows = (e.which == 40 || e.which == 38);
        var query = this.value;
        var pairedSuggestion = $(this).next(".abbv-search-suggestions");
        if( $(this).val().length >= charTrigger && !usedArrows) { clearSuggestions(); getSuggestions(pairedSuggestion, query, maxSuggestions);pairedSuggestion.show(); } 
        else if(usedArrows) { return;}
        else {clearSuggestions();pairedSuggestion.hide();}
        }
    );
    $('.abbv-search').on('keyup', function(e) {
        var pairedSuggestion = $(this).next('.abbv-search-suggestions');
        switch (e.which){
            case 40: e.preventDefault();
                if(pairedSuggestion.find('li.selected').length==0){
                    pairedSuggestion.find('li:first-child').addClass('selected'); break;
                }
                pairedSuggestion.find('li:not(:last-child).selected').removeClass('selected').next().addClass('selected'); break;
            case 38: e.preventDefault();
                pairedSuggestion.find('li:not(:first-child).selected').removeClass('selected').prev().addClass('selected'); break;
        }
        if(!pairedSuggestion.find('li.selected').length==0){
            $(this).val(pairedSuggestion.find('li.selected').children('a').html());
        }
    });
    $('.abbv-buddy button').on('click',function(){
        if($(".abbv-search-navigation").hasClass("abbv-search-active")){
            $(".abbv-search-navigation").removeClass("abbv-search-active");
            $(".abbv-search-toggle").click();
        }
        if($(this).hasClass('abbv-active')){
            $(this).hide().removeClass(function (index, className) {
                return (className.match (/(^|\s)abbv-icon\S+/g) || []).join(' ');
            }).addClass(this.dataset.openIcon).fadeIn(300);
            $(this).removeClass('abbv-active');
            $('#'+this.id+'-menu').hide();
        } else {
            $(this).hide().removeClass(function (index, className) {
                return (className.match (/(^|\s)abbv-icon\S+/g) || []).join(' ');
            }).addClass(this.dataset.closeIcon).fadeIn(300);
            $(this).addClass('abbv-active');
            $('#'+this.id+'-menu').fadeIn();
        }
    });

    //Listener to trigger search on press of enter
    var isArrowkey = false;
    var listSelectedIndex = 0;
    var pageTitle = document.getElementsByTagName("title")[0].innerHTML;
    $('header .abbv-search').on('keyup',function(e) {         
        if(e.which == 40 || e.which == 38) { 
            listSelectedIndex = $('header .abbv-search-suggestions').find('li.selected').index();
            isArrowkey = true;
        } else if(e.which != 13) {
            isArrowkey = false;
        }
        if(e.which == 13 && validateSearch($(this).val())) {
            sessionStorage.setItem('OriginTitle',pageTitle);
            if(isArrowkey){
                sessionStorage.setItem('AnlyticalTermType','Suggestion');
                sessionStorage.setItem('AutoPosition',listSelectedIndex.toString());
                isArrowkey = false;
            } else {
                sessionStorage.setItem('AnlyticalTermType','Typed');
            }
            window.location = this.dataset.resultsPage+'?q='+$(this).val();
        }
     });

    $('header .abbv-search-suggestions').on('click','a', function(e){
        e.preventDefault();
        var listIndex = $(this).parent().index();
        //Update search analytics properties on select suggestion list
        sessionStorage.setItem('AnlyticalTermType','Suggestion');
        sessionStorage.setItem('AutoPosition',listIndex.toString());
        sessionStorage.setItem('OriginTitle',pageTitle);
        // QUERY LOCATION
        window.location = $('.abbv-search').attr('data-results-page')+"?q=" + $(this).html();
    });
    $('header .abbv-search-navigation i').on('click',function(){
        var $searchInput = $(this).siblings('.abbv-search');        
        // QUERY LOCATION
        if(validateSearch($searchInput.val())){
            sessionStorage.setItem('OriginTitle',pageTitle);
            //Update search analytics properties on select typed
            var listIndex = $('header .abbv-search-suggestions').find('li.selected').index();
            if(listIndex >= 0) {
                sessionStorage.setItem('AnlyticalTermType','Suggestion');
                sessionStorage.setItem('AutoPosition',listIndex.toString());
            } else {
                sessionStorage.setItem('AnlyticalTermType','Typed');                
            }            
            window.location = $searchInput.attr('data-results-page')+"?q=" + $searchInput.val();            
        }
    });
    $('.abbv-search-suggestions').on('mouseenter',function(){$('.abbv-search-suggestions li.selected').removeClass('selected');})
    // Closes search suggestions of clicked anywhere outside of it
    $('body').click(function(e){
        var container = $(".abbv-search");
        if (!container.is(e.target)) { $(".abbv-search-suggestions").hide(); $('.abbv-search-suggestions li.selected').removeClass('selected');}
    });
    // Mobile Navigation
    $(".abbv-header-mobile-primary-navigation").click(function(){
        if($(".abbv-search-navigation").hasClass("abbv-search-active")){
            $(".abbv-search-navigation").removeClass("abbv-search-active");
            $(".abbv-search-toggle").click();
        }
        $('.abbv-buddy button').each(function(){
            if($(this).hasClass('abbv-active')){$(this).click();}
        });
        if($(this).hasClass("active")) {
            $(this).removeClass("active");
            $('.abbv-header-primary-navigation').removeClass('abbv-active');
        } else {
            $(this).addClass("active");
            $('.abbv-header-primary-navigation').addClass('abbv-active');
        }
    });
});

function clearSuggestions(){
    $('.abbv-search-suggestions ul').empty();
}

function getSuggestions(obj, query, maxS){   
    if(AbbViePageInfo.apiEndPoints.getSearchSuggestions != "") {
        //var _url = '/admp-common-elements/common-elements-aem-parent/ui.apps/src/main/content/jcr_root/apps/common-elements/v1/components/content/header/ui/data/searchSuggestions.json';
        var _url = AbbViePageInfo.apiEndPoints.getSearchSuggestions + '?query='+query+'&max_results='+maxS+'&beginning=0';
        ajaxCall(_url, "GET", "", onSucessSuggest, onFailedSuggest, true, "text");  
    } else {
        console.warn("getSearchSuggestions url not defined");
    }
    
    function onSucessSuggest(json) {
        clearSuggestions(); 
        var suggestions = JSON.parse(json.replace(/[{()}]/g, ''));
        var searchSuggestions = $(obj).find('ul');
        for (var i = 0; i <= suggestions.length - 1; i++) {
            searchSuggestions.append('<li><a href="javascript:void(0)" title="'+suggestions[i]+'">'+suggestions[i]+'</a></li>');
        }
    }
    
    function onFailedSuggest(jqXHR, textStatus, errorThrown){
        console.log(errorThrown);
    }
}

function validateSearch(valCheck){
    var regex = /^[a-zA-Z0-9@]/;
    return regex.test(valCheck);
}



//  decryptResponse().then(function(decryptedString) {
//      var userProfile = JSON.parse(decryptedString);
//      console.log(userProfile);
//      var values = {
//          firstName: userProfile.ContentResult.Consumer.FirstName,
//          lastName: userProfile.ContentResult.Consumer.LastName
//      };
//      var loggedinUserName = $('#loggedin-user-name').attr('data-welcome-text').replace(/\{\{([^}]+)\}\}/g, function(i, match) {
//      return values[match];});
//       $('#loggedin-user-name').empty().append(loggedinUserName);
//      }).catch(function (error) {
//        console.log("error in decryption");
//  }); 
// AbbVie Gird / List View Component 
$(document).ready(function () {
    // Initiate Masonry view on AEM
    masonryGrid.init();

    // Click List View
    $(".abbv-list-view-control").click(function () {
        $(".abbv-grid-list-view").addClass("abbv-list-view");
        $(".abbv-grid-view-control").removeClass("active");
        $(this).addClass("active");
        $(".abbv-hidden-panel").hide();
        $(".abbv-hidden-panel-open-active").removeClass("abbv-hidden-panel-open-active");
    });

    // Click Grid View
    $(".abbv-grid-view-control").click(function () {
        $(".abbv-grid-list-view").removeClass("abbv-list-view");
        $(".abbv-list-view-control").removeClass("active");
        $(this).addClass("active");
        $(".abbv-hidden-panel").hide();
        $(".abbv-hidden-panel-open-active").removeClass("abbv-hidden-panel-open-active");
    });
    // Grid / List Standard View Load More Setup
    $(document).on('click', '.abbv-show-more-control a', function (e) {
        e.preventDefault();
        if ($(this).closest('.abbv-grid-list-view').hasClass('masonry-view')) {
            //Initiate Masonry Grid View
            masonryGrid.createCards();
        }
        else {
            var currentGrid = $(this).parents(".abbv-grid-list-view").attr("id");
            var nextLoad = $(this).attr("data-url");
            $(this).closest(".abbv-show-more-control").remove();

            // Get More Cards
            $(".abbv-grid-list-view-temp").load(nextLoad, function () {
                // Load Cards Into Temporary Container + Append It From There
                $("#" + currentGrid + " .abbv-grid-cards-standard").append($(".abbv-grid-list-view-temp").html());
                // Empty Temporary Container
                $(".abbv-grid-list-view-temp").empty();
            });
        }
    });

});
// Masonry Grid
var masonryGrid = (function () {
    var $masonryElm,
        cardsUrl,
        nextSetCardsUrl,
        isCardsLoaded,
        colHeights = [],
        itemCol = 0,
        allCards = [],
        tempCards = [],
        LoadMoreURLCounter = 0,
        isInitiated = false,
        config,
        defaults;

    //Extend with default configurations
    function setConfig(opt) {
        config = $.extend({}, defaults, opt || {});
    }
    return {
        init: function (options) {
            $masonryElm = $('[data-masonry]');
            cardsUrl = $('.abbv-grid-list-view.masonry-view').attr('data-initial-load');
            defaults = {
                totalCols: $masonryElm.data('coloumn') || 3,
                colClass: 'abbv-col',
                cardClass: 'abbv-card',
                responsive: [{ breakpoint: 600, totalCols: 1 }]
            }
            if ($masonryElm.length) {
                setConfig(options);
                //Reset the variables on multiple initiate
                if (isInitiated && $masonryElm.find('.masonry-col').length) {
                    $('.masonry-col').remove();
                    nextSetCardsUrl = null;
                    colHeights.length = 0;
                    itemCol = 0;
                    allCards.length = 0;
                    tempCards.length = 0;
                    LoadMoreURLCounter = 0;
                }
                isInitiated = true;
                this.checkResponsive();
            }
        },
        //Check Responsive
        checkResponsive: function () {
            var windowWidth = window.innerWidth;
            var breakPointObj = getBreakPointObj(windowWidth, config['responsive']);
            if (breakPointObj !== undefined && config['responsive'].length) {
                config.totalCols = breakPointObj.totalCols;
            }
            function getBreakPointObj(viewPortWidth, responsiveArray) {
                for (var i = 0; i < responsiveArray.length; i++) {
                    if (viewPortWidth <= responsiveArray[i].breakpoint) {
                        return responsiveArray[i];
                    }
                }
            }
            this.createColumns();
        },
        //Create columns for stacking cards
        createColumns: function () {
            var columns = (12 / config.totalCols);
            for (var colCount = 0; colCount < config.totalCols; colCount++) {
                var newCol = $('<div/>', { class: config.colClass }).addClass('masonry-col abbv-col abbv-col-' + columns);
                $masonryElm.eq(0).append(newCol);
            }
            $masonryElm.find('.' + config.colClass).eq(0).addClass('abbv-col-first-of-row');
            this.createCards();
        },

        //Load cards detail 
        getCards: function (_url) {
            if (_url !== undefined && _url !== '') {
                ajaxCall(_url, "GET", "", onSucessGetCards, onFailedGetCards, true);
                //on sucesss save nextSetCardsUrl and show load more button
                function onSucessGetCards(data) {
                    var results = data.ContentResult;
                    tempCards = results.Cards;
                    if (results.NextSet !== null && results.NextSet !== "") {
                        nextSetCardsUrl = results.NextSet;
                        $('.abbv-show-more-control').css({ display: 'block' });
                    } else {
                        //nextSetCardsUrl url is not available, reset URL and hide load more button 
                        nextSetCardsUrl = null;
                        if ($('.abbv-show-more-control').is(':visible')) {
                            $('.abbv-show-more-control').css({ display: 'none' });
                        }
                    }
                    isCardsLoaded = true;
                }
                function onFailedGetCards() {
                    isCardsLoaded = false;
                    console.warn("Falied loading cards")
                }
            } else {
                console.warn("Cards url is not defined")
            }
        },

        //Create card dynamically and attach the properties
        createCards: function () {
            var _this = this;
            var _CardsURL = (LoadMoreURLCounter === 0) ? cardsUrl : nextSetCardsUrl;
            var imagesToPreload = [];
            this.getCards(_CardsURL);

            if (isCardsLoaded) {
                //Form array of images from loaded cards
                if (tempCards.length) {
                    for (var i = 0; i < tempCards.length; i++) {
                        var imgUrl = tempCards[i].ImageURL;
                        if (imgUrl !== '' && imgUrl !== null)
                            imagesToPreload.push(imgUrl);
                    }
                }

                //Preload all the card images
                masonryGrid.preLoadImages(imagesToPreload, afterLoadAllImages);

                //Create cards after load all images
                function afterLoadAllImages() {
                    for (var j = 0; j < tempCards.length; j++) {
                        var item = tempCards[j],
                            index = j,
                            card = $('<div/>', { class: config.cardClass }),
                            cardAnchorWrapper = $('<a/>', { target: item.CTATargetType, 'data-linktype': item.CTAType, title: item.CTAText }),
                            cardImageWrapper = $('<div/>', { class: 'abbv-card-image' }),
                            cardImage = $('<img/>', { src: item.ImageURL, title: item.ImageTitle, alt: item.ImageAlt }),
                            cardContentWrapper = $('<div/>', { class: 'abbv-card-text-content' }),
                            cardTitle = $('<h3/>').text(item.Title),
                            cardDescription = $('<div/>').html(item.Description),
                            linkmdObj = {
                                "type": item.CTAType,
                                "url": item.CTAURL,
                                "title": item.CTAText,
                                "component": {
                                    "type": item.CTAComponentType,
                                    "title": item.CTAComponentTitle,
                                    "name": item.CTAComponentName,
                                    "position": item.CTAComponentPosition
                                },
                                "journey": {
                                    "patient": item.PatientJourney,
                                    "content": item.ContentJourney,
                                    "message_bucket": item.MessageBucket
                                },
                                "mva": {
                                    "tier": item.AnalyticsMVATier,
                                    "type": item.AnalyticsMVAType,
                                    "value": item.AnalyticsMVAValue
                                }
                            };

                        //Added class, dataId and dataHref attribute based on CTAType
                        if (item.CTAType !== null && item.CTAType !== undefined) {
                            switch (item.CTAType) {
                                case "modal":
                                    cardAnchorWrapper.attr({ 'class': 'abbv-modal-open', 'data-id': item.CTAModalID });
                                    break;
                                case "image-modal":
                                    cardAnchorWrapper.attr({ 'class': 'abbv-modal-open', 'data-id': item.CTAModalID });
                                    break;
                                case "exit-modal":
                                    cardAnchorWrapper.attr({ 'class': 'abbv-modal-open abbv-exit-modal', 'data-id': item.CTAModalID, 'data-href': item.CTAURL });
                                    break;
                                case "hidden-panel":
                                    cardAnchorWrapper.attr({ 'class': 'abbv-hidden-panel-open', 'data-id': item.CTAModalID });
                                    break;
                                default:
                                    cardAnchorWrapper.attr({ 'href': item.CTAURL });
                            }
                        }
                        //Remove mva object from linkmd if AnalyticsEnableMVA is not true
                        if (item.AnalyticsEnableMVA !== 'true') {
                            delete linkmdObj['mva']
                        }
                        //Added analytics attribute linkmd
                        cardAnchorWrapper.attr({ "linkmd": JSON.stringify(linkmdObj) });
                        cardImage.appendTo(cardImageWrapper);
                        //Add image warpper only if image is available
                        if (item.ImageURL !== null && item.ImageURL !== '') {
                            cardImageWrapper.appendTo(cardAnchorWrapper)
                        }
                        cardTitle.appendTo(cardContentWrapper);
                        cardDescription.appendTo(cardContentWrapper);
                        cardContentWrapper.appendTo(cardAnchorWrapper);
                        cardAnchorWrapper.appendTo(card);

                        //Append card to the coloumn
                        _this.appendCardsInCol(card, index);
                    }

                    tempCards.forEach(function (cardItem) {
                        allCards.push(cardItem);
                    });
                    LoadMoreURLCounter++;

                }
            }
        },
        appendCardsInCol: function (card, cardIndex) {
            var $col = $masonryElm.find('.' + config.colClass),
                minColIndex = this.minIndex(colHeights),
                $currentCol;
            if (cardIndex < config.totalCols && !allCards.length) {
                reArrangeCards(itemCol);
            } else {
                reArrangeCards(minColIndex);
            }
            itemCol = (itemCol < config.totalCols - 1) ? itemCol + 1 : 0;
            function reArrangeCards(colIndex) {
                $currentCol = $col.eq(colIndex)
                $currentCol.append(card);
                colHeights[colIndex] = $currentCol.outerHeight();
            }
        },
        //find minimum value from the array
        minIndex: function (arry) {
            var minValue = Math.min.apply(Math, arry);
            return arry.indexOf(minValue, arry);
        },
        preLoadImages: function (sources, callback) {
            let counter = 0;
            function onLoad() {
                counter++;
                if (counter == sources.length) callback();
            }
            for (var i = 0; i < sources.length; i++) {
                let img = document.createElement('img');
                img.onload = img.onerror = onLoad;
                img.src = sources[i];
            }
        }
    }

})();
$(document).ready(function() {
    if($('.abbv-formulary').length != 0){ formularyLookup.init(); }
    
    $('.formulary-dropdown-box span').on('click', function(){
        if($(this).hasClass('abbv-active')){ $(this).removeClass('abbv-active'); $('#formulary-dropdown-list').fadeOut();}
        else{ $(this).addClass('abbv-active'); formularyLookup.showSuggestions(); $('#formulary-dropdown-input').focus();}
    })

    $('.formulary-dropdown-values .formulary-list-item').on("click", function(e) {
        e.preventDefault();
        $('#formulary-dropdown-input').val($(this).text());
        var searchText = $('#formulary-dropdown-input').val();
        formularyLookup.formularySearch(searchText);
        $('.formulary-dropdown-values').hide();
    });
    $('#formulary-dropdown-input').on('keyup',function(e){
        var searchText = $('#formulary-dropdown-input').val();
        var pairedSuggestion = $('.formulary-dropdown-values');
        var myElement;
        var topPos;
        formularyLookup.showSuggestions(searchText);
        switch (e.which){
            case 13: e.preventDefault();
                let searchText = $('#formulary-dropdown-input').val();
                let searchTerm;
                if(pairedSuggestion.find('li.selected').length != 0){
                    searchTerm = $('.formulary-dropdown-values li.selected').text();
                } else if($('#formulary-dropdown-input').hasClass('invalidInput')){
                    break;
                } else {
                    searchTerm = searchText;
                }
                formularyLookup.formularySearch(searchTerm);
                return;
                break;
            case 40: e.preventDefault();
                if(pairedSuggestion.find('li.selected:visible').length==0){
                    pairedSuggestion.find('li.selected').removeClass('selected');
                    if(pairedSuggestion.find('li:first-child').is(':visible')){
                        pairedSuggestion.find('li:first-child').addClass('selected');
                    } else {
                        pairedSuggestion.find('li:visible').eq(0).addClass('selected');
                    }
                    myElement = pairedSuggestion.find('li.selected')[0];
                    topPos = myElement.offsetTop;
                    document.getElementById('formulary-dropdown-list').scrollTop = topPos;
                }else{
                    pairedSuggestion.find('li:not(:last-child).selected').removeClass('selected').next(':visible').addClass('selected');
                    if(pairedSuggestion.find('li.selected').length != 0){
                        myElement = pairedSuggestion.find('li.selected')[0];
                        topPos = myElement.offsetTop;
                        document.getElementById('formulary-dropdown-list').scrollTop = topPos;
                    }
                }
                break;
            case 38: e.preventDefault();
                pairedSuggestion.find('li:not(:first-child).selected').removeClass('selected').prev(':visible').addClass('selected');
                if(pairedSuggestion.find('li.selected').length != 0){
                    myElement = $('li.selected')[0];
                    topPos = myElement.offsetTop;
                    document.getElementById('formulary-dropdown-list').scrollTop = topPos;
                }
                break;
        }
        formularyLookup.validateInput(searchText);
    });
    $('.formulary-dropdown-values').on('mouseenter',function(){$('.formulary-dropdown-values li.selected').removeClass('selected');})
    $('body').click(function(e){
        var container = $('.formularyInput-wrapper span');
        var containerTwo = $('#formulary-dropdown-input');
        if (!container.is(e.target) && !containerTwo.is(e.target)) { 
            $('.formulary-dropdown-box span').removeClass('abbv-active');
            $("#formulary-dropdown-list").fadeOut();
            $('.formulary-dropdown-values li.selected').removeClass('selected');
        }
    });
    $('.formulary-dropdown-box #formulary-lookup-btn').on('click', function(){
        $('.formulary-dropdown-values').hide();
        var searchText = $('#formulary-dropdown-input').val();
        formularyLookup.formularySearch(searchText);
    });

    $('.abbv-formulary .formulary-error button').on('click',function(){
		$(this).closest('.abbv-formulary').find('.formulary-error').removeClass('abbv-active');
		$(this).closest('.abbv-formulary').find('.main-error span').empty();
	});
});

var formularyLookup = (function() {
    var formularyData;
    var dataList;
    return{
        init : function(){
            formularyLookup.getData();
            formularyLookup.generateList();
            $('#formulary-dropdown-input').addClass('invalidInput')
        },
        getData: function(){
            var lookupJSON = $('.abbv-formulary').attr('data-lookup-json');
            ajaxCall(lookupJSON, "GET", "", successGet, failGet, true);
        },
        setData: function(data){
            formularyData = data;
        },
        //Appending Dropdown Values
        generateList : function() {
            $.each(formularyData, function(key, value) {
                if ( value.state.name != -1 ) {
                    $('#formulary-dropdown-list').append('<li class="formulary-list-item" tabindex ="4" value="'+value.state.name+'">'+value.state.name+'</li>');
                        $('#formulary-dropdown-list, .formulary-note').hide();
                }
            })
            dataList = $('#formulary-dropdown-list');
        },
        validateInput : function(expression){
            var foundMatch = false;
            $.each(formularyData, function(key, value) {
                if(!foundMatch){
                    if ( value.state.name.toUpperCase() == expression.toUpperCase()) {
                        $('#formulary-dropdown-input').removeClass('invalidInput').addClass('validInput');
                        $('.formulary-dropdown-box .abbv-button-primary').prop('disabled', false);
                        foundMatch = true;
                    } else {
                        $('#formulary-dropdown-input').removeClass('validInput').addClass('invalidInput');
                        $('.formulary-dropdown-box .abbv-button-primary').prop('disabled', true);
                    }
                }
            })
        },
        //Search Text matching
        showSuggestions : function(expression) {
            // console.log('suggestion trigger');
            $('#formulary-dropdown-list').fadeIn();
            $('.formulary-dropdown-box span').addClass('abbv-active');
            var items, test, txtValue;
            var userInput = expression == undefined ? '' : expression.toUpperCase();
            items = $(dataList).find('li');
            // console.log(items);
            for (let i = 0; i < items.length; i++) {
                if(expression == ''){ items[i].style.display = ""; }
                test = items[i];
                txtValue = test.textContent.toUpperCase() || test.innerText.toUpperCase();
                // console.log(txtValue);
                if (txtValue.indexOf(userInput) === 0) {
                    items[i].style.display = "";
                } else {
                    items[i].style.display = "none";
                }
            }
        },
        // Formulary Lookup button click
        formularySearch : function(expression) {
            var flag = false;
            $.each(formularyData, function(key, value) {
                var ele ='';
                var title='';
                if( value.state.name.toUpperCase() == expression.toUpperCase() ) {
                    title = expression;
                    flag = true;
                    for(var i=0; i < value.state.zone.length; i++) {
                        ele += '<div class="formulary-zone abbv-col abbv-col-6">'
                        if(value.state.zone[i].name == ''){
                            ele += '<h3 class="formulary-state-name">' +title+'</h3>';
                        }else {
                            ele += '<h3 class="formulary-state-name">' +title+'- <span>'+value.state.zone[i].name+'</span></h3>';
                        }
                        for(var j=0; j < value.state.zone[i].account.length; j++) {
                            ele +='<div class="formulary-account">';
                            ele +='<div class="formulary-account-name">' +value.state.zone[i].account[j].name+'</br></div>';
                            ele +='<div class="formulary-account-language">'+value.state.zone[i].account[j].language+'</br></div>';
                            ele +='</div>';      
                        }
                        ele +='</div>';
                        if(i % 2 != 0) {
                          ele +='<div class="clearfix"></div>';
                        }
                      $('#formulary-results-container').html('');
                      $('#formulary-results-container').html(ele);
                      $('.formulary-note').show();
                    }
                    $('.abbv-formulary-results').fadeIn();
                    $("html, body").animate({ scrollTop: Math.ceil($('.abbv-formulary-results').offset().top+fixedTracking.getOffset('top')) }, "slow");
                }  
            })
            if(flag == false) {
                var target = $('.abbv-formulary').find('.main-error span');
                var noResults = $(target).attr('data-no-results');
                  target.empty();
                  target.text(noResults);
                  $('.formulary-error').addClass('abbv-active');
            }
            // RESET 
            $('.formulary-dropdown-values li.selected').removeClass('selected');
            $('#formulary-dropdown-input').removeClass('validInput').addClass('invalidInput').val('');
            $('.formulary-dropdown-box .abbv-button-primary').prop('disabled', true);
            $('.formulary-dropdown-input').blur();
            $('.formulary-dropdown-box span').removeClass('abbv-active');
            $('.formulary-dropdown-values').hide();
        },
        printObj : function(){
            console.log(formularyData);
            console.log(dataList);
        }

    };
})();
function successGet(data, textStatus, jqXHR){ formularyLookup.setData(data) }
function failGet(jqXHR, textStatus, errorThrown){ 
    var target = $('.abbv-formulary').find('.main-error span');
    var noResults = $(target).attr('data-failed-load');
    target.empty();
    target.text(noResults);
    $('.formulary-error').addClass('abbv-active');
}



// AbbVie Flexbox Component
$(document).ready(function() {
  
});


$(document).ready(function () {
	if (typeof google != "undefined") {
		dlLocator.initAPI();
	}
	$('#use_geo').on('click', function () {
		var toggleOn = $(this).hasClass('abbv-active') ? false : true;
		$('.location .abbv-error-msg').empty();
		if (toggleOn) {
			$('.abbv-dr-locator .loading').show();
			$(this).addClass('abbv-active');
			dlLocator.getLocation();
			$('#zip_code').attr("disabled", true);
			$('#zip_code').val('');
		} else {
			$(this).removeClass('abbv-active');
			$('#zip_code').attr("disabled", false);
			$('.location .abbv-error-msg').empty();
		}
	});
	$('#zip_code').on('keyup', function () {
		$('.location .abbv-error-msg').empty();
	});
	$('#zip_code').on('invalid', function (e) {
		e.preventDefault();
	});
	$('#reset-form').on('click', function () {
		$('.abbv-error-msg').each(function () {
			$(this).empty();
		});
		$('#use_geo').removeClass('abbv-active');
		$('#zip_code').attr("disabled", false);
	});
	$('.terms input').on('change', function () {
		$('.terms .abbv-error-msg').empty();
	});
	$('#showMap').on('click', function () {
		$('.DLResults').toggleClass('mapShown');
		$(this).toggleClass('abbv-active');
	});
	$('.abbv-dr-locator .main-error button').on('click', function () {
		var $drLocatorObj = $(this).closest('.abbv-dr-locator');
		$drLocatorObj.find('.main-error').removeClass('abbv-active');
		$drLocatorObj.find('.main-error span').empty();
		$drLocatorObj.find('.loading').hide();
		$drLocatorObj.find('.loading .abbv-animation-loading').show();
		//If doctor list available scroll to results
		if ($('.DLResults').length) {
			var drLocatorOffsetTop = $('.abbv-dr-locator form').offset().top;
			$("html, body").animate({ scrollTop: Math.ceil(drLocatorOffsetTop - fixedTracking.getOffset('top',drLocatorOffsetTop)) }, "slow");
		}
	});
	$('#submit_dr-location').on('click', function () {
    dlLocator.resetVars();
		$('.DLResults').hide();
		if ($('#zip_code').val() == '' && !$('#use_geo').hasClass('abbv-active')) {
			$('.location .abbv-error-msg').text($('.location .abbv-error-msg').attr('data-err-location'));
		} else if ($('#zip_code').is(':invalid')) {
			$('.location .abbv-error-msg').text($('.location .abbv-error-msg').attr('data-err-zip'));
		} else {
			// Attempt to initialize, checking user input.
			if (!dlLocator.checkTerms()) {
				$('.terms .abbv-error-msg').text($('.terms .abbv-error-msg').attr('data-err-terms'));
			} else {
				$('.abbv-dr-locator .loading').show();
				var objectInitialized = dlLocator.initObj();
				if (objectInitialized) {
					// Post Payload and parse results to object
					setTimeout(function () { dlLocator.handleDLPayload(true); }, 500);
				} else { console.log("Failed to Initialize Object"); }
			}
		}

	});
	$('.radiusFilter select').change(function () {
		$('.abbv-dr-locator .loading').show();
		dlLocator.setNextSet(1, 1);
		dlLocator.setRadius($(this).val());
		setTimeout(function () { dlLocator.handleDLPayload(true); }, 500);
	});
	$(document).on('click', '.abbv-drawer-link', function () {
		$(this).empty();
		if ($('#' + this.id.split('-')[1]).hasClass('abbv-active')) {
			$('#' + this.id.split('-')[1]).removeClass('abbv-active');
			$(this).text('Show all practice details +');
		} else {
			$('#' + this.id.split('-')[1]).addClass('abbv-active');
			$(this).text('Show less -');
		}
	});
	$(document).on('click', '.docLink', function () {
		$('div [title="' + $(this).parent().attr('title') + '"]').click();
	});
	$(document).on('click', '.dlPagination a', function () {
		$('.abbv-dr-locator .loading').show();
		dlLocator.setNextSet(this.dataset.pageNum, this.dataset.startItem);
		setTimeout(function () { dlLocator.handleDLPayload(false); }, 500);
	});
});

var dlLocator = (function () {
	var sLocation = {};
	var sLocationPoint;
	var locationSet = false;
	var provider;
	var zip;
	var speciality;
	var condition;
	var termsChecked;
	var locations = [];
	var markers = [];
	var searchRadius;
	var paginationObj = {};
	var mapInitialized = false;
	var initErr;
	var geocoder;
	var bounds;
	var map;
	var markerLabels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	var labelIndex = 0;
	var markerFill;
	var labelColor;
	var markerStroke;
	var markerPath;
	var dLerrors = {};

	return {
		initAPI: function () {
			geocoder = new google.maps.Geocoder();
		},
		initObj: function () {
			// console.log("dlLocator Object Initialized");
			paginationObj.nextStart = 1;
			dlLocator.setLocation();
			dlLocator.setSpeciality();
			dlLocator.setCondition();
			dlLocator.setRadius($('.abbv-dr-locator').attr('data-search-radius'));
			dlLocator.setPerPage($('.abbv-dr-locator').attr('data-results-perPage'));
			markerFill = $('.abbv-dr-locator').attr('data-marker-fill');
			labelColor = $('.abbv-dr-locator').attr('data-label-color');
			markerStroke = $('.abbv-dr-locator').attr('data-marker-stroke');
			markerPath = $('.abbv-dr-locator').attr('data-marker-path');
			dLerrors.invZip = $('.location .abbv-error-msg').attr('data-err-zip') == undefined ? "Invalid Zipcode" : $('.location .abbv-error-msg').attr('data-err-zip');
			dLerrors.noRes = $('.abbv-dr-locator').find('.main-error span').attr('data-err-no-results') == undefined ? "No Results Found" : $('.abbv-dr-locator').find('.main-error span').attr('data-err-no-results');
			dLerrors.noAPI = $('.abbv-dr-locator').find('.main-error span').attr('data-err-no-api') == undefined ? "Something went wrong, please try again later" : $('.abbv-dr-locator').find('.main-error span').attr('data-err-no-api');
			if (markerPath == undefined) { markerPath = "M9,26.1C1.4,15.2,0,14,0,10C0,4.5,4.5,0,10,0s10,4.5,10,10c0,4-1.4,5.2-9,16.1c-0.4,0.6-1.1,0.7-1.7,0.3 C9.2,26.3,9.1,26.2,9,26.1z" }
			return true;
		},
		initMap: function () {
			// console.log('initMap'); 
			// console.log('setting center to:');
			mapInitialized = false;
			if (sLocationPoint == undefined) {
				setTimeout(function () { dlLocator.initMap(); }, 1000);
			} else {
				var myOptions = {
					center: sLocationPoint,
					zoom: 10,
					MapTypeId: google.maps.MapTypeId.ROADMAP
				};

				map = new google.maps.Map(document.getElementById('docMap'), myOptions);

				mapInitialized = true;
			}
		},
		initPagination: function (total) {
			// console.log('initPagination');
			paginationObj.totalResults = parseInt(total);
			paginationObj.pageTotal = Math.ceil(total / paginationObj.perPage);
			paginationObj.currentPage = 1;
			paginationObj.nextPage = 2
			paginationObj.lowerLimit = 1;
			paginationObj.upperLimit = (paginationObj.perPage > paginationObj.totalResults) ? paginationObj.totalResults : paginationObj.perPage;

			// Build page array
			var pages = [];
			for (let i = 0; i < paginationObj.pageTotal; i++) {
				var temp = '<a class="dlPagination-link" href="javascript:void(0)" data-page-num="' + (i + 1) + '"data-start-item="' + ((i * paginationObj.perPage) + 1) + '" title="Page ' + (i + 1) + '">' + (i + 1) + '</a>';

				pages.push(temp);
			}
			paginationObj['pages'] = pages;

			// console.log(paginationObj);

			// Update custom label template
			var values = {
				rangeLower: paginationObj.lowerLimit,
				rangeUpper: paginationObj.upperLimit,
				totalResults: paginationObj.totalResults
			};
			$('#dataRange').empty().append($('#dataRange').attr('data-structure').replace(/\{\{([^}]+)\}\}/g, function (i, match) {
				return values[match];
			}));

			// Empty pagination
			$('.dlPagination ul').empty();

			if (paginationObj.pageTotal > 5) {
				$('.dlPagination ul').removeClass('simple-control').addClass('expanded-control');
				let isFirst = true;
				$('.dlPagination ul').append('<li id="firstPage"><a class="inactive" data-page-num="1" data-start-item="1" title="First page"><i></i></a></li>');
				$('.dlPagination ul').append('<li id="previousPage"><a class="inactive" data-page-num="" data-start-item="" title="Previous page"><i></i></a></li>');
				let maxViewed = paginationObj.pageTotal < 5 ? paginationObj.pageTotal : 5;
				for (let i = 0; i < maxViewed; i++) {
					if (isFirst) { $('.dlPagination ul').append('<li class="abbv-active">' + paginationObj.pages[i] + '</li>'); isFirst = false; }
					else { $('.dlPagination ul').append('<li>' + paginationObj.pages[i] + '</li>'); }
				}
				$('.dlPagination ul').append('<li id="nextPage"><a class="" data-page-num="' + paginationObj.nextPage + '" data-start-item="' + ((paginationObj.nextPage - 1) * paginationObj.perPage + 1) + '" title="Next page"><i></i></a></li>');
				$('.dlPagination ul').append('<li id="lastPage"><a class="" data-page-num="' + paginationObj.pageTotal + '" data-start-item="' + ((paginationObj.pageTotal - 1) * paginationObj.perPage + 1) + '" title="Last page"><i></i></a></li>');
			} else {
				$('.dlPagination ul').removeClass('expanded-control').addClass('simple-control');
				let isFirst = true;
				$('.dlPagination ul').append('<li id="previousPage"><a class="inactive" data-start-item="" title="Previous page"><i></i></a></li>');
				let maxViewed = paginationObj.pageTotal < 5 ? paginationObj.pageTotal : 5;
				for (let i = 0; i < maxViewed; i++) {
					if (isFirst) { $('.dlPagination ul').append('<li class="abbv-active">' + paginationObj.pages[i] + '</li>'); isFirst = false; }
					else { $('.dlPagination ul').append('<li>' + paginationObj.pages[i] + '</li>'); }
				}
				if (paginationObj.pageTotal == 1) {
					$('.dlPagination ul').append('<li id="nextPage"><a class="inactive" data-page-num="' + paginationObj.nextPage + '" data-start-item="' + ((paginationObj.nextPage - 1) * paginationObj.perPage + 1) + '" title="Next page"><i></i></a></li>');
				} else {
					$('.dlPagination ul').append('<li id="nextPage"><a class="" data-page-num="' + paginationObj.nextPage + '" data-start-item="' + ((paginationObj.nextPage - 1) * paginationObj.perPage + 1) + '" title="Next page"><i></i></a></li>');
				}
			}
		},
		setRadius: function (val) {
			// console.log('setRadius');
			searchRadius = val;
			if (!mapInitialized) {
				$('.radiusFilter select').val(searchRadius);
			}
		},
		setPerPage: function (val) {
			// console.log('setPerPage');
			paginationObj.perPage = parseInt(val);
		},
		getLocation: function () {
			// Check if geolocation is available
			if ("geolocation" in navigator) {
				// Try to get user current location using getCurrentPosition() method
				navigator.geolocation.getCurrentPosition(function (position) {
					// console.log('inside getpos');
					sLocation['lat'] = position.coords.latitude;
					sLocation['lon'] = position.coords.longitude;
					sLocationPoint = new google.maps.LatLng(sLocation.lat, sLocation.lon);
					locationSet = true;
					$('.abbv-dr-locator .loading').hide();
					return true;
				}, function (positionErr) {
					$('#use_geo').removeClass('abbv-active');
					$('#zip_code').attr("disabled", false);
					$('.location .abbv-error-msg').text('Enable location services to use this feature');
					$('.abbv-dr-locator .loading').hide();
					return false;
				});
			} else {
				$('.location .abbv-error-msg').text('Browser does not support this feature');
			}
		},
		setLocation: function () {
			// console.log('setLocation');
			var useGeo = $('#use_geo').hasClass('abbv-active') ? true : false;
			var locErr = "";
			// Check if geolocation is to be used
			if (!useGeo) {
				locationSet = false;
				sLocation = {};
				sLocationPoint = undefined;
				zip = document.getElementById('zip_code').value;
				geocoder.geocode({ 'address': document.getElementById('zip_code').value }, function (results, status) {
					if (status == google.maps.GeocoderStatus.OK) {
						sLocation['lat'] = (results[0].geometry.location.lat());
						sLocation['lon'] = (results[0].geometry.location.lng());
						sLocationPoint = new google.maps.LatLng(sLocation.lat, sLocation.lon);
					} else {
						locErr = "Request failed for zip -> lat, long";
						return locErr;
					}
				});
			}
		},
		setSpeciality: function () {
			// console.log('setSpeciality');
			speciality = '';
			var specChecked = false;
			if ($('.speciality input[type=radio]:checked').length != 0) {
				// GET CONDITION SELECTIONS
				$('.speciality input[type=radio]').each(function () {
					if (this.checked) {
						speciality = (this.value);
						specChecked = true;
					}
				});
			}
			if ($('.speciality input[type=checkbox]:checked').length != 0) {
				var isFirst = true;
				$('.speciality input[type=checkbox]').each(function () {
					if (this.checked) {
						if (isFirst) {
							speciality = (this.value);
							isFirst = false;
						} else {
							speciality = speciality + ',' + (this.value);
						}
						specChecked = true;
					}
				});
			}
			if (!specChecked) {
				speciality = $('.abbv-dr-locator').attr('data-speciality');
			}
		},
		setCondition: function () {
			// console.log('setCondition'); 
			condition = '';
			var condChecked = false;
			if ($('.condition input[type=radio]:checked').length != 0) {
				// GET CONDITION SELECTIONS
				$('.condition input[type=radio]').each(function () {
					if (this.checked) {
						condition = (this.value);
						condChecked = true;
					}
				});
			}
			if (!condChecked) {
				var dataCondition = $('.abbv-dr-locator').attr('data-condition');
				if (dataCondition === null || dataCondition === undefined) {
					condition = "";
				} else {
					condition = dataCondition;
				}
			}
		},
		checkTerms: function () {
			// console.log('checkTerms');
			if ($('.terms input[type=checkbox]').is(':checked')) {
				termsChecked = true;
				return true;
			} else {
				termsChecked = false;
				return false;
			}
		},
		buildDLPayload: function () {
			// console.log('buildDLPayload');
			var zipVar = locationSet ? "" : zip;
			var latVar = locationSet ? sLocation.lat : "";
			var lonVar = locationSet ? sLocation.lon : "";
			var payload =
			{
				"PhysicianAddress": {
					"AddressLine1": "",
					"AddressLine2": "",
					"City": "",
					"State": "",
					"Zipcode": zipVar
				},
				"SpecialtyName": speciality,
				"SearchRadius": searchRadius,
				"InsuranceProviderId": "",
				"IndicationId": $('.abbv-dr-locator').attr('data-indication-id'),
				"TermsConditionsCheck": termsChecked,
				"RecordsFrom": paginationObj.nextStart,
				"RecordCount": paginationObj.perPage,
				"ConditionsTreated": condition,
				"GeoCoordinates": {
					"Latitude": latVar,
					"Longitude": lonVar
				}
			};
			// console.log(payload);
			return JSON.stringify(payload);
		},
		handleDLPayload: function (initPage) {
			if (AbbViePageInfo.apiEndPoints.physicianLookUp != "") {
				// console.log('handleDLPayload');
				var payload = dlLocator.buildDLPayload();
				var search_api_url = AbbViePageInfo.apiEndPoints.physicianLookUp;
				//var search_api_url = "/api/BrandAPIGateway/api/Physician/LookUp";
				//var search_api_url = "https://www-d.commonelements.humira.com/api/BrandAPIGateway/api/Physician/LookUp";				
				//Enabling common ajax call for search api
				ajaxCall(search_api_url, "POST", payload, onSucessDocSearch, onFailedDocSearch, true);

				//On Success Doc search
				function onSucessDocSearch(data) {
					// console.log(data);
					if (data.IsStatusSuccessful) {
						//Show map and doclist if hide
						if (!$('#docList').is(':visible')) {
							$('#showMap').show();
							$('#docList').show();
							$('#docMap').show();
						}
						//Initialize Map
						if (!mapInitialized) { dlLocator.initMap(); }
						if (initPage) {
							dlLocator.initPagination(data.ContentResult.MatchCount);
						}
						else {
							dlLocator.updatePagination();
						}
						dlLocator.setMarkers(data.ContentResult);
						$('.abbv-dr-locator .DLResults').show();
						$('.abbv-dr-locator .loading').hide();
						$("html, body").animate({ scrollTop: Math.ceil($('.DLResults').offset().top - fixedTracking.getOffset('top',$('.DLResults').offset().top)) }, "slow");
					} else {
						$('.abbv-dr-locator').find('.main-error span').empty();
						var errors = data.ErrorResponseMessageList;
						// Test error code and inject error messages here.
						if (errors[0] == null) {
							console.log('Non payload error');
						} else if (errors[0].ErrorCode == "51012") {
							$('.abbv-dr-locator .loading').hide();
							$('.location .abbv-error-msg').text(dLerrors.invZip);
						} else if (errors[0].ErrorCode == "51020" || errors[0].ErrorCode == "51019") {
							$("html, body").animate({ scrollTop: Math.ceil($('.abbv-dr-locator form').offset().top - fixedTracking.getOffset('top')) }, "slow");
							$('.abbv-dr-locator').find('.loading .abbv-animation-loading').hide();
							$('.abbv-dr-locator').find('.main-error span').text(dLerrors.noRes);
							$('.abbv-dr-locator').find('.main-error').addClass('abbv-active');
							//Hide doclist, map, pagination and set mapInitialized false if the result is not found
							$('#dataRange').text(dLerrors.noRes);
							$('.dlPagination ul').empty();
							$('#docList').hide();
							$('#docMap').hide();
							$('#showMap').hide();
							mapInitialized = false;
						}
						else {
							$("html, body").animate({ scrollTop: Math.ceil($('.abbv-dr-locator form').offset().top - fixedTracking.getOffset('top')) }, "slow");
							$('.abbv-dr-locator').find('.loading .abbv-animation-loading').hide();
							$('.abbv-dr-locator').find('.main-error span').text(errors[0].ErrorMessage);
							$('.abbv-dr-locator').find('.main-error').addClass('abbv-active');
						}
					}
				}

				//On failed Doc search
				function onFailedDocSearch(jqXHR, textStatus, errorThrown) {
					// console.log('ajax fail');
					$('.abbv-dr-locator').find('.main-error span').empty();
					if (textStatus == "timeout") {
						$("html, body").animate({ scrollTop: Math.ceil($('.abbv-dr-locator form').offset().top - fixedTracking.getOffset('top')) }, "slow");
						$('.abbv-dr-locator').find('.loading .abbv-animation-loading').hide();
						$('.abbv-dr-locator').find('.main-error span').text("Search has timed out, please try again");
						$('.abbv-dr-locator').find('.main-error').addClass('abbv-active');
						return 0;
					} else {
						$("html, body").animate({ scrollTop: Math.ceil($('.abbv-dr-locator form').offset().top - fixedTracking.getOffset('top')) }, "slow");
						$('.abbv-dr-locator').find('.loading .abbv-animation-loading').hide();
						$('.abbv-dr-locator').find('.main-error span').text(dLerrors.noAPI);
						$('.abbv-dr-locator').find('.main-error').addClass('abbv-active');
					}
				}
			} else { console.warn("physicianLookUp url not defined"); }
		},
		setMarkers: function (data) {
			if (mapInitialized) {
				locations = [];
				for (let i = 0; i < markers.length; i++) {
					markers[i].setMap(null);
				}
				markers = [];
				labelIndex = 0;
				for (let i = 0; i < data.RecordCount; i++) {
					var temp = [];
					temp.push(data.Party[i].partyNameField + ', ' + data.Party[i].hCPExtensionField.degreeCodeField) //Name + Degree Title
					if (data.Party[i].partyAddressField != null) {
						temp.push(data.Party[i].partyAddressField[0].latitudeField);
						temp.push(data.Party[i].partyAddressField[0].longitudeField);
						temp.push(data.Party[i].partyAddressField[0].addressLine1Field);
						temp.push(data.Party[i].partyAddressField[0].cityNameField + ', ' + data.Party[i].partyAddressField[0].stateProvinceCodeField + ' ' + data.Party[i].partyAddressField[0].postalCodeField);
					} else { temp.push('', '', '', ''); }
					if (data.Party[i].communicationField != null) {
						temp.push(data.Party[i].communicationField[0].communicationValueTextField);
					} else { temp.push(''); }
					if (data.Party[i].communicationField != null) {
						if (data.Party[i].communicationField[0].communicationTypeDescriptionField == "Telephone") {
							temp.push('tel:');
						} else if (data.Party[i].communicationField[0].communicationTypeDescriptionField == "Primary") {
							temp.push('mailto:');
						} else {
							temp.push('');
						}
					} else { temp.push(''); }
					if (data.Party[i].partyAddressField != null) {
						temp.push((data.Party[i].partyAddressField[0].distanceInMilesField).substring(0, 4) + ' mi');
					} else { temp.push(''); }
					if (data.Party[i].specialtyField != null) {
						temp.push(data.Party[i].specialtyField[0].specialtyDescriptionField);
					} else { temp.push(''); }
					temp.push(data.Party[i].hCPExtensionField.graduationSchoolNameField);
					if (data.Party[i].hCPBrandDataField[0].yearsInPracticeField != null) {
						temp.push(data.Party[i].hCPBrandDataField[0].yearsInPracticeField);
					} else { temp.push(''); }
					if (data.Party[i].hCPBrandDataField[0].acceptingNewPatientsField != null) {
						temp.push(data.Party[i].hCPBrandDataField[0].acceptingNewPatientsField);
					} else { temp.push(''); }
					if (data.Party[i].hCPBrandDataField[0].businessAffiliationsField != null) {
						temp.push(data.Party[i].hCPBrandDataField[0].businessAffiliationsField);
					} else { temp.push(''); }
					locations.push(temp);
				}
				var markerIcon = {
					path: markerPath,
					size: new google.maps.Size(20, 26),
					origin: new google.maps.Point(0, 0),
					anchor: new google.maps.Point(10, 32),
					fillColor: markerFill,
					fillOpacity: 1,
					scale: 1,
					strokeColor: markerStroke,
					strokeWeight: 2,
					labelOrigin: new google.maps.Point(10, 11)
				}

				$('.drList ul').empty();
				var infowindow = new google.maps.InfoWindow();
				for (let i = 0; i < locations.length; i++) {

					var name = locations[i][0]
					var lat = locations[i][1]
					var long = locations[i][2]
					var add1 = locations[i][3]
					var add2 = locations[i][4]
					var coms = locations[i][5]
					var comsType = locations[i][6]
					var dist = locations[i][7]
					var spec = locations[i][8]
					var school = locations[i][9]
					var years = locations[i][10]
					var newPat = locations[i][11]
					var affil = locations[i][12]

					var latlngset = new google.maps.LatLng(lat, long);

					var marker = new google.maps.Marker({
						icon: markerIcon,
						label: {
							text: markerLabels[labelIndex % markerLabels.length],
							color: labelColor,
						},
						map: map,
						title: name,
						position: latlngset,
						zIndex: (locations.length - i),
					});

					var directionLink = 'https://www.google.com/maps/dir/?api=1&destination=' + lat + ',' + long;
					var content = '<a class="docLink"><strong>' + name + '</strong></a><br><span>' + add1 + '<br>' + add2 + '<br><a href="' + comsType + coms + '">' + coms + '</a></span>';

					google.maps.event.addListener(marker, 'click', (function (marker, content, infowindow) {
						return function () {
							infowindow.setContent(content + '<br>' + '<a href="' + directionLink + '" target="_blank">Get Directions</a>');
							infowindow.open(map, this);
							if ($('.drList li.abbv-active').length != 0) {
								$('.drList li.abbv-active').removeClass('abbv-active');
							}
							$('.drList li[title="' + this.title + '"]').addClass('abbv-active');

						};
					})(marker, content, infowindow));
					markers.push(marker);

					var distDirLine = dist + ' | <a class="abbv-icon-directions_car i-b" href="' + directionLink + '" target="_blank">Get Directions</a>';
					var specInfo = spec != '' ? '<p><strong>Specialty:</strong><br>' + spec + '</p>' : '';
					var yearsInfo = years != '' ? '<p><strong>Years in Practice:</strong><br>' + years + '</p>' : '';
					var schoolInfo = school != '' ? '<p><strong>Education:</strong><br>' + school + '</p>' : '';
					var newPatInfo = newPat != '' ? '<p><strong>Accepting New Patients:</strong><br>' + newPat + '</p>' : '';
					var affilInfo = affil != '' ? '<p><strong>Hospital Affiliations:</strong><br>' + affil + '</p>' : '';
					var moreLink = '<a class="abbv-drawer-link" id="trigger-drawer' + i + '">Show all practice details +</a>';
					var moreInfo = specInfo + yearsInfo + schoolInfo + newPatInfo + affilInfo;
					var moreContainer = '<div class="abbv-drawer" id="drawer' + i + '">' + moreInfo + '</div>';
					$('.drList ul').append('<li title="' + name + '"><span style="color:' + labelColor + '" class="DLlistLabel">' + markerLabels[labelIndex++] + '</span><svg version="1.1" class="DLlistIcon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 26.1" style="enable-background:new 0 0 20 26.1;" xml:space="preserve" fill="' + markerFill + '" stroke="' + markerStroke + '"><g><path d="' + markerPath + '"/></g></svg>' + content + '<br><br>' + distDirLine + '<br>' + moreLink + moreContainer + '</li>');
				}
				// dlLocator.initPagination(data.MatchCount);
			} else {
				setTimeout(function () {
					dlLocator.setMarkers(data);
				}, 500);
			}
			// console.log(markers);
		},
		setNextSet: function (page, start) {
			// console.log('setNextSet');
			paginationObj.nextPage = parseInt(page);
			paginationObj.nextStart = parseInt(start);
		},
		updatePagination: function () {
			// console.log('updatePagination');
			paginationObj.lowerLimit = paginationObj.nextStart;
			paginationObj.upperLimit = ((paginationObj.lowerLimit + paginationObj.perPage) > paginationObj.totalResults) ? paginationObj.totalResults : paginationObj.lowerLimit + paginationObj.perPage - 1;
			var values = {
				rangeLower: paginationObj.lowerLimit,
				rangeUpper: paginationObj.upperLimit,
				totalResults: paginationObj.totalResults
			};
			// console.log(paginationObj);
			$('#dataRange').empty().append($('#dataRange').attr('data-structure').replace(/\{\{([^}]+)\}\}/g, function (i, match) {
				return values[match];
			}));

			// Empty pagination
			$('.dlPagination ul').empty();

			if (paginationObj.pageTotal > 5) {
				var startNum;
				if (paginationObj.nextPage + 2 <= paginationObj.pageTotal) {
					if (paginationObj.nextPage - 2 > 0) { startNum = paginationObj.nextPage - 2; }
					else if (paginationObj.nextPage - 1 > 0) { startNum = paginationObj.nextPage - 1; }
					else { startNum = paginationObj.nextPage; }
				} else if (paginationObj.nextPage + 1 <= paginationObj.pageTotal) { startNum = paginationObj.nextPage - 3; }
				else { startNum = paginationObj.nextPage - 4; }
				startNum--;
				// console.log(paginationObj.nextPage)
				if (paginationObj.nextPage == 1) {
					$('.dlPagination ul').append('<li id="firstPage"><a class="inactive" data-page-num="1" data-start-item="1" title="First page"><i></i></a></li>');
					$('.dlPagination ul').append('<li id="previousPage"><a class="inactive" data-page-num="" data-start-item="" title="Previous page"><i></i></a></li>');

				} else {
					$('.dlPagination ul').append('<li id="firstPage"><a class="" data-page-num="1" data-start-item="1" title="First page"><i></i></a></li>');
					$('.dlPagination ul').append('<li id="previousPage"><a class="" data-page-num="' + (paginationObj.nextPage - 1) + '" data-start-item="' + ((paginationObj.nextPage - 2) * paginationObj.perPage + 1) + '" title="Previous page"><i></i></a></li>');
				}
				for (let i = startNum; i < startNum + 5; i++) {
					if (i + 1 == paginationObj.nextPage) { $('.dlPagination ul').append('<li class="abbv-active">' + paginationObj.pages[i] + '</li>'); }
					else { $('.dlPagination ul').append('<li>' + paginationObj.pages[i] + '</li>'); }
				}
				if (paginationObj.nextPage == paginationObj.pageTotal) {
					$('.dlPagination ul').append('<li id="nextPage"><a class="inactive" data-page-num="" data-start-item="" title="Next page"><i></i></a></li>');
					$('.dlPagination ul').append('<li id="lastPage"><a class="inactive" data-page-num="' + paginationObj.pageTotal + '" data-start-item="' + ((paginationObj.pageTotal - 1) * paginationObj.perPage + 1) + '" title="Last page"><i></i></a></li>');

				} else {
					$('.dlPagination ul').append('<li id="nextPage"><a class="" data-page-num="' + (paginationObj.nextPage + 1) + '" data-start-item="' + ((paginationObj.nextPage) * paginationObj.perPage + 1) + '" title="Next page"><i></i></a></li>');
					$('.dlPagination ul').append('<li id="lastPage"><a class="" data-page-num="' + paginationObj.pageTotal + '" data-start-item="' + ((paginationObj.pageTotal - 1) * paginationObj.perPage + 1) + '" title="Last page"><i></i></a></li>');
				}
			} else {
				if (paginationObj.nextPage == 1) {
					$('.dlPagination ul').append('<li id="previousPage"><a class="inactive" data-start-item="" title="Previous page"><i></i></a></li>');
				} else {
					$('.dlPagination ul').append('<li id="previousPage"><a class="" data-page-num="' + (paginationObj.nextPage - 1) + '" data-start-item="' + ((paginationObj.nextPage - 1) * paginationObj.perPage + 1) + '" title="Previous page"><i></i></a></li>');
				}
				var maxViewed = paginationObj.pageTotal < 5 ? paginationObj.pageTotal : 5;
				for (let i = 0; i < maxViewed; i++) {
					if (i + 1 == paginationObj.nextPage) { $('.dlPagination ul').append('<li class="abbv-active">' + paginationObj.pages[i] + '</li>'); }
					else { $('.dlPagination ul').append('<li>' + paginationObj.pages[i] + '</li>'); }
				}
				if (paginationObj.nextPage != paginationObj.pageTotal) {
					$('.dlPagination ul').append('<li id="nextPage"><a class="" data-page-num="' + (paginationObj.nextPage + 1) + '" data-start-item="' + ((paginationObj.nextPage) * paginationObj.perPage + 1) + '" title="Next page"><i></i></a></li>');
				} else {
					$('.dlPagination ul').append('<li id="nextPage"><a class="inactive" data-page-num="" data-start-item="" title="Next page"><i></i></a></li>');
				}
			}
		},
		printObj: function () {
			console.log("---Object Printout---");
			console.log("sLocation");
			console.log(sLocation);
			console.log("\nProvider");
			console.log(provider);
			console.log("\nSpeciality");
			console.log(speciality);
			console.log("\nSpeciality");
			console.log(condition);
			console.log("\nTerms Checked");
			console.log(termsChecked);
			console.log("\nReturned Locations");
			console.log(locations);
			console.log("\nError:");
			console.log(initErr);
			console.log("\nMap:");
			console.log(map);
			console.log("-----End Object-----");
			return "done";
		},
		resetVars: function () {
			zip = "";
			speciality = "";
			termsChecked = false;
			locations = [];
			markers = [];
			searchRadius = "";
			paginationObj = {};
			mapInitialized = false;
			labelIndex = 0;
		}
	};
})();
(function ($, $document) {
    "use strict";
 
      $document.on("dialog-ready", function() {
          var handler = function(indicationVal, specialities, currentSpeciality){
			var specValue = specialities[indicationVal];
            if(!specValue){return;}
			var checkboxList = specValue.split(",");
            var cboxText;
			var checkboxTemplate;
			var fieldsetField = $(".speciality-fieldset.coral-Form-fieldset");
            fieldsetField.find(".coral-Form-fieldwrapper").remove();
            for(var i=0; i< checkboxList.length; i++){
				cboxText = checkboxList[i];
				checkboxTemplate = '<div class="coral-Form-fieldwrapper coral-Form-fieldwrapper--singleline">' +
                    '<label class="coral-Checkbox coral-Form-field">' +
                    '<input type="checkbox" name="./specialty" value="'+cboxText+'" data-validation="" class="coral-Checkbox-input" data-fieldlabel="'+ cboxText +'" aria-invalid="false">'+
                    '<span class="coral-Checkbox-checkmark"></span>'+
                    '<span class="coral-Checkbox-description">'+cboxText+'</span>' +
                    '<input type="hidden" name="./specialty@Delete">' +
                    '</label>' +
                    '<span class="coral-Form-fieldinfo coral-Icon coral-Icon--infoCircle coral-Icon--sizeS" data-init="quicktip" data-quicktip-type="info" data-quicktip-arrow="left" data-quicktip-content="Enable the specialty options to be displayed." aria-label="Enable the specialty options to be displayed." tabindex="0"></span>'+
                    '</div>';
                var checkboxField = $(checkboxTemplate);
				fieldsetField.append(checkboxField);
            }

            if(currentSpeciality){
                  var existingSpecialities = [];
                  if(typeof currentSpeciality === "string"){
                      existingSpecialities = currentSpeciality.split(",");
                  }else{
                      existingSpecialities = currentSpeciality;
                  }
                  for(var j=0; j<existingSpecialities.length; j++){
                      var speciality = existingSpecialities[j];
                      $("input[name='./specialty'][value='"+speciality+"']").attr('checked', 'checked');                     
                  }
              }
          };

          // Fetch speciality values
          var fetchSpecList = function(initialIndicationVal, currentSpeciality){
			var dynamicSiteName =window.location.pathname.split("/")[3];
			var specialityListUrl = "/content/admin/"+dynamicSiteName+"/en-us/ce-doctor-locator-area-of-specialities-list/_jcr_content/list.infinity.json";
            var spltyListDefaultUrl = "/content/admin/common-elements/en-us/ce-doctor-locator-area-of-specialities-list/_jcr_content/list.infinity.json";

              $.getJSON(specialityListUrl,function(json){
                  if(json.item === undefined){
					specialityListUrl = spltyListDefaultUrl;
                  }
                  getSpecialityList(specialityListUrl);
           		 }).fail(function(err){

					getSpecialityList(spltyListDefaultUrl);

             	 });


              function getSpecialityList(URL){
                 $.getJSON(URL, function(specData){
                  var specialities = {};
                  for(var key in specData) {
                    if (specData.hasOwnProperty(key)) {
                        var specItem = specData[key];
                        if(specItem.value && specItem["jcr:title"]){
                            specialities[specItem["jcr:title"]] = specItem.value;
                        }

                      }
                  }
                  handler(initialIndicationVal, specialities, currentSpeciality);
              })

              }


          };

		var actionUrl = $("select[name='./indication']").closest("form").attr("action");
          $.getJSON(actionUrl+".json", function(data){
              var initialIndicationVal = $("select[name='./indication']").val();
          fetchSpecList(initialIndicationVal, data.specialty);

          });
        $("select[name='./indication']").closest(".coral-Select").find(".coral-SelectList-item").on("click", function(val){
            fetchSpecList($(this).attr("data-value"), undefined);
        });
    });
      
})($, $(document));

var pieChart = (function() {

	var $chartObj;
	var chartObj;
    var $baseWrapper;
	var $chartDataObj;
	var pieces = [];
    var chartH;
    var chartHRange;
    var cValue;
    var pieOutRadius;
    var pieTrueOutRadius;
    var pieInRadius;
    var pieTrueInRadius;
    var pieTrueRadius;
    var adjustedRadius;
    var adjustedCvalue;
    var adjustedStroke;
    var dashOffset;
    var chartCount = 0;

	return {
        init : function(chart){
        	chartObj = chart;
        	$chartObj = $(chartObj);
            $baseWrapper = $($chartObj.find('.abbv-chart-base-wrapper'));
            chartH = Number(chart.dataset.graphH);
            chartHRange = Number(chart.dataset.vaxisMax - chart.dataset.vaxisMin);
        	$chartDataObj = $chartObj.find('.abbv-chart-data');
            cValue = 0;
            pieces = $chartDataObj.find('.pie-piece');
            pieOutRadius = $chartDataObj.data('oradius');
            pieInRadius = $chartDataObj.data('iradius');
            pieTrueOutRadius = chartH/Number(chartHRange/pieOutRadius);
            pieTrueInRadius = chartH/Number(chartHRange/pieInRadius);
            pieTrueRadius = (pieOutRadius + pieInRadius)/2;
            adjustedRadius = chartH/Number(chartHRange/pieTrueRadius);
            adjustedStroke = (chartH/(chartHRange/(pieOutRadius - pieTrueRadius)))*2;
            adjustedCvalue = 2*Math.PI*adjustedRadius;
            let startPoint = (0.25 - ($chartDataObj.data('spoint')*(25/3))/100);

            dashOffset = startPoint < 0 ? -1*(adjustedCvalue * (-1*startPoint)) : adjustedCvalue * startPoint;
            for(let h = 0; h < pieces.length; h++){
                let tempPiece = pieces[h].querySelector('.piece-draw');
                tempPiece.setAttribute('r',adjustedRadius);
                cValue += Number(tempPiece.getAttribute('data-value'));
            }
            chartCount++;
    		pieChart.buildChart();
    	},
    	buildChart : function(){
            // SET THE BASE STYLES IN AN INLINE CSS BLOCK
            var pieBaseStyles = '';
            pieBaseStyles += '#'+$chartDataObj.attr('id')+' .piece-draw { ';
            pieBaseStyles += 'stroke-width: '+adjustedStroke+';';
            // pieBaseStyles += 'r: '+adjustedRadius+';';
            pieBaseStyles += 'stroke-dashoffset: '+dashOffset+';';
            pieBaseStyles += 'stroke-dasharray: 0,0,0,'+Math.round(adjustedCvalue*100)/100+';}';
            // END BASE STYLES
            var pieStyles = '';
            var keyStyles = '';

            var nodeBase = document.createElement('style');
            $chartObj.find('.abbv-chart-base-wrapper').append(nodeBase);
            nodeBase.innerHTML = pieBaseStyles;

            let runningCount = 0;
			// Do stuff
            for(let i = 0; i < pieces.length; i++){
                var curPiece = pieces[i].querySelector('.piece-draw');
                var curLabel = pieces[i].querySelector('.pie-value-label');

                let tempStyleClass = 'piece-draw-'+chartCount+'-'+i;
                $(curPiece).addClass(tempStyleClass);

                var pieceVal = Number(curPiece.getAttribute('data-value'));
                var piecePer = pieceVal/cValue;

                let strokeLength = adjustedCvalue*piecePer;
                let strokeGap = adjustedCvalue - strokeLength;

                let labelArcStep = dashOffset - (strokeLength/2);
                let labelThetaRStep = labelArcStep/adjustedRadius;
                let labelRad = 0;

                if($(curLabel).hasClass('label-outer')){
                    labelRad = pieTrueInRadius +(adjustedStroke * (2/3));
                } else if ($(curLabel).hasClass('label-outside')){
                    labelRad = pieTrueOutRadius*(5/4);

                } else {
                    labelRad = adjustedRadius;
                }
                let labelX = labelRad * Math.sin(labelThetaRStep + Math.PI/2);
                let labelY = labelRad * Math.cos(labelThetaRStep + Math.PI/2);

                let startL, startG, nextL, nextG;

                if(i==0){
                    startL = Math.round(strokeLength*100)/100;
                    startG = Math.round(strokeGap*100)/100;
                    nextL = 0;
                    nextG = 0;
                } else {
                    startL = 0;
                    startG = Math.round(runningCount*100)/100;
                    nextL = Math.round(strokeLength*100)/100;
                    nextG = Math.round((adjustedCvalue - (runningCount + strokeLength))*100)/100;
                }

                let tempDarray = 'stroke-dasharray:'+startL+','+startG+','+nextL+','+nextG+';';

                if($baseWrapper.hasClass('abbv-draw-pie')){
                    pieStyles += '.abbv-draw-pie.inView .abbv-chart-data .'+tempStyleClass+'{';
                    pieStyles += '-webkit-animation: '+tempStyleClass+' 4s ease both;';
                    pieStyles += 'animation: '+tempStyleClass+' 4s ease both;}';

                    keyStyles += '@-webkit-keyframes '+tempStyleClass+'{ 50%,100% {'+tempDarray+'}}';
                    keyStyles += '@keyframes '+tempStyleClass+'{ 50%,100% {'+tempDarray+'}}';
                } else {
                    pieStyles += '#'+$chartDataObj.attr('id')+' .'+tempStyleClass+'{';
                    pieStyles += tempDarray+'}';
                }

                curLabel.setAttribute('x',labelX);
                curLabel.setAttribute('y',labelY);

                runningCount += strokeLength;
                dashOffset -= strokeLength;
            }
            // console.log(pieStyles1+pieKeyFrames);
            var nodePieS = document.createElement('style');
            $chartObj.find('.abbv-chart-base-wrapper').append(nodePieS);
            nodePieS.innerHTML = pieStyles + keyStyles;
            // Show Chart
            $chartObj.find('.abbv-chart-base-wrapper').addClass('abbv-loaded');
            $chartObj.find('.loading').fadeOut();
            $baseWrapper.find('.abbv-chart-base').each(function(){
                $(this).find('.abbv-axis-group').hide();
            });
            animationsObj.scrollListen();
    	},
    	printObj : function(){
    		console.log($chartObj);
    		console.log(chartObj);
    		console.log($chartDataObj);
    	}
    };
})();

var lineChart = (function() {

    var $chartObj;
    var chartObj;
    var $baseWrapper;
    var $chartDataObj;
    var lines = [];
    var chartW;
    var chartH;
    var chartWRange;
    var chartHRange;
    var xLeft;
    var yTop;
    var pointRad;
    var curvedLine;

    return {
        init : function(chart){
            chartObj = chart;
            $chartObj = $(chartObj);
            $baseWrapper = $($chartObj.find('.abbv-chart-base-wrapper'));
            chartW = Number(chart.dataset.graphW);
            chartH = Number(chart.dataset.graphH);
            chartWRange = Number(chart.dataset.haxisMax - chart.dataset.haxisMin);
            chartHRange = Number(chart.dataset.vaxisMax - chart.dataset.vaxisMin);
            $chartDataObj = $chartObj.find('.abbv-chart-data');
            xLeft = Number($chartObj.attr('xLeft'));
            yTop = Number($chartObj.attr('yTop'));
            lines = $chartDataObj.find('.data-line');
            pointRad = parseInt($chartDataObj.attr('data-point-radius'));
            curvedLine = $chartDataObj.hasClass('curved-line') ? true : false;
            lineChart.buildChart();
        },
        buildChart : function(){
            // console.log(lines);
            // Do stuff
            for(let i = 0; i < lines.length; i++){
                var pointObjs = $(lines[i]).find('.data-point');
                let lineCont = $(lines[i]).find('.line-draw');
                // console.log(pointObjs);
                var tempLineConstr = '<path class="abbv-line" d="';
                var tempLineValConst = '';
                var pointsArr = [];
                let tempX = xLeft;
                var firstPass = true;
                for(let j = 0; j < pointObjs.length; j++){
                    if(firstPass){ $(pointObjs[j]).addClass('first-point');}
                    let pointDraw = pointObjs[j].querySelector('.point-draw');
                    let pointLabel = pointObjs[j].querySelector('.point-value-label');
                    let tempOffset;
                    if($(pointObjs[j]).hasClass("label-below")){
                        tempOffset = 15;
                    } else { tempOffset = -15;}
                    let pointVal = $(pointDraw).data('value');
                    // console.log(pointVal);
                    let tempY = -1*chartH*(pointVal/chartHRange);
                    let tempPoint = [tempX,tempY];
                    pointsArr[j] = tempPoint;

                    pointDraw.setAttribute('cx',tempX);
                    pointDraw.setAttribute('cy',tempY);
                    pointDraw.setAttribute('r',pointRad);

                    pointLabel.setAttribute('x',tempX);
                    pointLabel.setAttribute('y',tempY + tempOffset);
                    if(!curvedLine){
                        let lineVarD;
                        if(firstPass){
                            lineVarD = "M"
                        } else { lineVarD = " L"}
                        tempLineValConst += lineVarD+tempX+' '+tempY;
                    }

                    tempX += chartW/(pointObjs.length-1);
                    firstPass = false;
                    // console.log(tempPoint);
                }
                if(curvedLine){
                    var firstPoint = pointsArr[0]
                    var tempString = lineChart.getCurvedLine(pointsArr);
                    var curvedLineCode = "M"+firstPoint[0]+" "+firstPoint[1]+tempString;
                    tempLineValConst = curvedLineCode;
                }
                tempLineConstr += tempLineValConst+'"/>';
                lineCont.html(tempLineConstr);
                if(browserAgent.checkIfBrowser('ie')){
                    var newLine = document.createElementNS("http://www.w3.org/2000/svg","path");
                    $(newLine).addClass('abbv-line');
                    newLine.setAttribute('d',tempLineValConst);
                    lineCont.append(newLine);                
                }
            }
            if(browserAgent.checkIfBrowser('ie')){
                $chartObj.find('text').each(function(){
                    this.setAttribute('dy','5');
                });
            }
            // Show Chart
            $chartObj.find('.abbv-chart-base-wrapper').addClass('abbv-loaded');
            $chartObj.find('.loading').fadeOut();
            animationsObj.scrollListen();
        },
        getCurvedLine : function(points){
            var curveLineDraw = "";
            for(let k = 0; k < points.length-1; k++){
                curveLineDraw += lineChart.getCurve(points[k+1],k+1,points);
            }
            return curveLineDraw;
        },
        getCurve : function(point, place, points){
            // start control point
            var startCpoint = lineChart.getControlPoint(points[place - 1], points[place - 2], point);
            var cpsX = startCpoint[0];
            var cpsY = startCpoint[1];
            // end control point
            var endCpoint = lineChart.getControlPoint(point, points[place - 1], points[place + 1], true);
            var cpeX = endCpoint[0];
            var cpeY = endCpoint[1];
            return 'C '+cpsX+' '+cpsY+' '+cpeX+' '+cpeY+' '+point[0]+' '+point[1];
        },
        getLineProps : function(pointA, pointB){
            // console.log(pointA);
            // console.log(pointB);
            var lengthX = pointB[0] - pointA[0]
            var lengthY = pointB[1] - pointA[1]
            return {
                length: Math.sqrt(Math.pow(lengthX, 2) + Math.pow(lengthY, 2)),
                angle: Math.atan2(lengthY, lengthX)
            }
        },
        getControlPoint : function(current, previous, next, rev){
            var p = previous === undefined ? current : previous;
            var n = next === undefined ? current : next;

            var smoothing = 0.2;

            var lObject = lineChart.getLineProps(p,n);

            var angle = lObject.angle + (rev ? Math.PI : 0);
            var length = lObject.length * smoothing;

            var x = current[0] + Math.cos(angle) * length;
            var y = current[1] + Math.sin(angle) * length;

            return [x,y];
        },
        printObj : function(){
            console.log($chartObj);
            console.log(chartObj);
            console.log($chartDataObj);
        }
    };
})();

var barChart = (function() {
    // INITIALIZE GENERAL VARIABLES
    var $chartObj;
    var chartObj;
    var $baseWrapper;
    var $chartDataObj;
    var bars = [];
    var groupingLabels = [];
    var chartW;
    var chartH;
    var chartWRange;
    var chartHRange;
    var xLeft;
    var yTop;

    return {
        // INITIALIZE CHART OBJECT
        init : function(chart){
            chartObj = chart;
            $chartObj = $(chartObj);
            $baseWrapper = $($chartObj.find('.abbv-chart-base-wrapper'));
            chartW = Number(chart.dataset.graphW);
            chartH = Number(chart.dataset.graphH);
            chartWRange = Number(chart.dataset.haxisMax - chart.dataset.haxisMin);
            chartHRange = Number(chart.dataset.vaxisMax - chart.dataset.vaxisMin);
            $chartDataObj = $chartObj.find('.abbv-chart-data');
            bars = $chartDataObj.find('.data-bar');
            groupingLabels = $chartDataObj.find('.group-label');
            xLeft = Number($chartObj.attr('xLeft'));
            yTop = Number($chartObj.attr('yTop'));
            let groupingAttrib = $chartDataObj.attr('data-grouping');
            let groupingVar = groupingAttrib != undefined ? Number(groupingAttrib) : 0;
            barChart.buildChart(groupingVar);
        },
        buildChart : function(grouping){
            let isIE = browserAgent.checkIfBrowser('ie');
            let barGap;
            let groupGap;
            let tempCurBarPos;
            let varSizeVar;
            let staticSizeVar;
            let varDimVar;
            let staticDimVar;
            let varDimMult;
            let staticDimMult;
            let varDimDiv;
            let mStack;
            let mStackVar;
            let grouped = grouping !=0 ? true : false;
            let numGroups = (grouped) ? bars.length/grouping : 0;
            let barGapPer = parseInt($chartDataObj.attr('data-bar-gap'));
            let groupGapPer = 3 * barGapPer;
            let barSpace = 1 - (((barGapPer*(bars.length-numGroups))+(groupGapPer*numGroups))/100);
            // Set the vars for vertical bar chart
            if($chartDataObj.hasClass('bars-vertical')){
                varSizeVar = "x";
                staticSizeVar = "y";
                varDimVar = "height"
                staticDimVar = "width";
                varDimMult = chartH;
                staticDimMult = chartW;
                varDimDiv = chartHRange;
                mStack = "chart-margin-vertical";
                mStackVar = $baseWrapper.attr('data-vStack');
                barGap = chartW*(barGapPer/100);
                groupGap = chartW*(groupGapPer/100);
                tempCurBarPos = (grouped) ? groupGap/2 + xLeft : barGap/2 + xLeft;
            } 
            // Set the vars for horizontal bar chart
            else if ($chartDataObj.hasClass('bars-horizontal')){
                varSizeVar ="y";
                staticSizeVar = "x";
                varDimVar = "width"
                staticDimVar = "height";
                varDimMult = chartW;
                staticDimMult = chartH;
                varDimDiv = chartWRange;
                mStack = "chart-margin-horizontal";
                mStackVar = $baseWrapper.attr('data-hStack');
                barGap = chartH*(barGapPer/100);
                groupGap = chartH*(groupGapPer/100);
                tempCurBarPos = (grouped) ? groupGap/2 + yTop : barGap/2 + yTop;
            } else {
                console.warn('bar direction class missing');
            }
            let barWidth = (staticDimMult*barSpace)/bars.length;
            let delta; let deltaShift; let deltaCount = 0;
            if(grouped){
                delta = staticDimMult / (2*numGroups);
                deltaShift = delta;
                $baseWrapper.removeClass(mStack+mStackVar);
                $baseWrapper.addClass(mStack+(parseInt(mStackVar)+1));
            }
            var oneStepStack = true;
            var labelsPresent = false;
            for(let i = 0; i < bars.length; i++){
                let barRect = bars[i].querySelector('.bar-draw');
                let barValLabel = bars[i].querySelector('.bar-value-label');
                let barLabel = bars[i].querySelector('.bar-label');
                let isNegative = $(barRect).data('value') < 0 ? true : false;
                labelsPresent = barLabel.innerHTML != "" ? true : false;                
                if(labelsPresent && oneStepStack){
                    $baseWrapper.removeClass(mStack+mStackVar);
                    $baseWrapper.addClass(mStack+(parseInt(mStackVar)+1));
                    oneStepStack = false;
                }
                let tempCalc = varDimMult*($(barRect).data('value')/varDimDiv);
                let valLabelPos;
                let varDimVal;
                let labelPosSwitch = $(barValLabel).hasClass('label-in') ? -1 : 1;
                if(tempCalc < 1){
                    varDimVal = tempCalc * -1;
                    valLabelPos = varDimVal + 10 * labelPosSwitch;
                    if($chartDataObj.hasClass('bars-horizontal')){
                        $(bars[i]).addClass("negative-shift");
                        if(isIE){
                            let rotatePoint = '0 '+(tempCurBarPos+(barWidth/2));
                            $(bars[i]).find('.bar-draw')[0].setAttribute("transform","rotate(180 "+rotatePoint+")");
                        }
                        valLabelPos = -1 * varDimVal -10 * labelPosSwitch;
                    }
                } else {
                    varDimVal = tempCalc;
                    if($chartDataObj.hasClass('bars-vertical')){
                        $(bars[i]).addClass("positive-shift");
                        if(isIE){
                            let rotatePoint = (tempCurBarPos+(barWidth/2))+' 0';
                            $(bars[i]).find('.bar-draw')[0].setAttribute("transform","rotate(180 "+rotatePoint+")");
                        }
                        valLabelPos = -1 * varDimVal -10 * labelPosSwitch;
                    }
                    else { valLabelPos = varDimVal +10 * labelPosSwitch; }
                }

                barRect.setAttribute(varSizeVar,tempCurBarPos);
                barRect.setAttribute(staticSizeVar,0);
                barRect.setAttribute(staticDimVar,barWidth);
                barRect.setAttribute(varDimVar,varDimVal);

                barValLabel.setAttribute(varSizeVar,tempCurBarPos+(barWidth/2));
                barValLabel.setAttribute(staticSizeVar, valLabelPos);

                barLabel.setAttribute(varSizeVar,tempCurBarPos+(barWidth/2));
                let flipSwitch = isNegative ? -1 : 1;
                if($chartDataObj.hasClass('bars-horizontal')){
                    if(isNegative) {
                        barLabel.setAttribute(staticSizeVar,(0 + 10));
                    } else {
                        barLabel.setAttribute(staticSizeVar,(0 - 10));
                    }
                    if(isIE){
                        $chartDataObj.find('.group-labels').attr('transform','rotate(180)');
                        $chartDataObj.find('.group-label').attr('dx','-5');
                    }
                } else {
                    barLabel.setAttribute(staticSizeVar,10*flipSwitch)
                }

                if(grouped && (i+1) % grouping === 0 ){
                    let labelCompensation = labelsPresent ? 15 : 0;
                    let tempGroupLabel = groupingLabels[deltaCount];
                    tempGroupLabel.setAttribute(staticSizeVar,(10 + labelCompensation)*flipSwitch);
                    tempGroupLabel.setAttribute(varSizeVar,deltaShift);
                    deltaShift += (2*delta);
                    deltaCount++;
                }

                if(groupGap != 0 && (i+1) % grouping === 0 ){
                    tempCurBarPos += groupGap + barWidth;
                } else {
                    tempCurBarPos += barGap + barWidth;
                }
            }
            if(isIE){
                $chartObj.find('text').each(function(){
                    this.setAttribute('dy','5');
                });
            }
            $chartObj.find('.abbv-chart-base-wrapper').addClass('abbv-loaded');
            $chartObj.find('.loading').fadeOut();
            animationsObj.scrollListen();
        },
        printObj : function(){
            console.log($chartObj);
            console.log(chartObj);
            console.log($chartDataObj);
            console.log(bars);
        }
    };
})();
// AbbVie Brand Explorer
$(document).ready(function() {
   $('.brand-nav-toggle-expand').on("click", function(){
         var that = this;
         // if tab clicked active close brand explorer else open
         if($(that).hasClass('active')){closeBrandExplorer();}
         else{openBrandExplorer(); activateDimmer('closeBrandExplorer');}
   });
   // Close button visible only when brand explorer is expanded open
   $('.brand-nav-close').on("click", function(){
         closeBrandExplorer();
         deactivateDimmer();
   });
   // Hide all tab containers + open default container
   $('.abbv-tab-container').hide();
   // show the default or active set on load
   $('.abbv-tab-container.active').fadeIn();
   $('.abbv-tab').on("click", function(){
      $(".abbv-tab-container").stop(true, true);
		var that = this;
      // swap tab____ with container____ to get target container associated with tab
      var panelShow = $("#"+this.id.replace("tab","container"));
      // if clicked tab is not active
		if(!$(that).hasClass('active')){
         // remove active class/styling to current active tab
         $('.abbv-tab').removeClass('active');
         // apply active to clicked tab
         $(that).addClass('active');
         // Remove styling from active container +fade out current container
         $('.abbv-tab-container.active').hide().removeClass('active');
         // apply active to clicked tab content container + fade in
         panelShow.addClass('active').fadeIn(400);
      }
   });
   // + trigger for collapsed link group items 
   $('.abbv-link-group-trigger').on('click', function(){
      var that = this;
      $(that).parents('.abbv-link-group').toggleClass('showMe');
   });
});

function openBrandExplorer(){
   // check if the safety bar is present if yes, store in variable
   if(sBar.checkLife()){ sBar.updateSbVar(); var sBar_height = sBar.getSbHeight();}
   // else set variable to 0
   else { var sBar_height = 0; }
   // add showMe class + set max height to space available - safety bar space
   $('.abbv-brand-explorer-drawer').addClass('showMe').css('max-height',($(window).height() - (sBar_height+$('.abbv-brand-explorer-navigation').height())));
   // set the max height of the content inside the drawer to available space minus the navigation & the padding
   $('.abbv-brand-explorer-drawer-content').css('max-height',($(window).height() - (sBar_height+180)));
   // hide the brand explorer toggle button
   $('.brand-nav-toggle-expand').fadeOut(200);
   // Freeze page to prevent the ability to scroll the content behind brand explorer
   // activateDimmer('closeBrandExplorer');
   $('.abbv-content-container').addClass('abbv-freeze-top');
}
function closeBrandExplorer(instant){
   // clear max-height and remove showMe, causing collaps back to default state
   $('.abbv-brand-explorer-drawer').css('max-height','').removeClass('showMe');
   // undim overlay
   if(instant){
      // fade back in toggle button
      $('.brand-nav-toggle-expand').fadeIn(200);
      // remove the freeze class that fixes the content, preventing scrolling while brand explorer is open
      $('.abbv-content-container').removeClass('abbv-freeze-top');
   }
   else{
      // $('.abbv-dimmer').fadeOut(300);
      setTimeout(function(){
         // fade back in toggle button
         $('.brand-nav-toggle-expand').fadeIn(200);
         // remove the freeze class that fixes the content, preventing scrolling while brand explorer is open
         $('.abbv-content-container').removeClass('abbv-freeze-top');
      }, 700);
   }
}
// AbbVie Brand Explorer
$(document).ready(function() {
   // Brand Exporer (Release 6 JS Code).
   // Differentiate JS Functions as they will be overlapping for ~2 months.
    brandExplorer.init();
   	$('#brand-explorer-expand').on('click',function(){
   		brandExplorer.openExplorer();
   		activateDimmer('brandExplorer.closeExplorer');
   	});
   	$('#brand-explorer-close').on('click',function(){
   		brandExplorer.closeExplorer();
   		deactivateDimmer();
   	});
   	$('.link-grouping-t0').on('click', function(){
   		brandExplorer.navToSub($(this));
   	});
   	$('#brand-explorer-back').on('click', function(){
   		brandExplorer.goBack();
   	});
   	$('#brand-explorer-home').on('click', function(){
   		brandExplorer.goHome();
   	});
   	$('.explore-link-options').on('click', function(){
   		let $panelTarget = $('#'+this.dataset.panelId);
   		// console.log(temp);
   		brandExplorer.navigateToPanel($panelTarget);
   		return false;
   	});
});

var brandExplorer = (function() {

    var userPos;
    var $activeSub;
    var $activePanel;
    var $linkExplore;
    var $homeSlider;
    var $explorerBackBTN;
    var $explorerHomeBTN;

  	return {
    	init : function(){
    		userPos = 0;
    		$linkExplore = $('.abbv-link-exploration');
    		$homeSlider = $('.brand-explorer-home-slider');
    		$explorerBackBTN = $('#brand-explorer-back');
    		$explorerHomeBTN = $('#brand-explorer-home');
	    },
	    openExplorer : function(){
	    	$('#brand-explorer-expand').fadeTo(300,0);
	    	let sBar_height;
	    	// check if the safety bar is present if yes, store in variable
		   	if(sBar.checkLife()){ sBar.updateSbVar(); sBar_height = sBar.getSbHeight();}
		   	// else set variable to 0
		   	else { sBar_height = 0; }
		   	// add abbv-active class + set max height to space available - safety bar space
	    	$('.abbv-brand-explorer-panel-container').addClass('abbv-active').css('max-height',($(window).height() - (sBar_height+$('.abbv-brand-explorer-bar').height())));
    		$('.abbv-brand-explorer-panel-container-wrapper').fadeTo(300,1);
	    	setTimeout(function(){
		    	$('.abbv-brand-explorer-bar').addClass('abbv-active');
	    		$('#brand-explorer-expand').hide();
	    	},500);
        setTimeout(function(){$('.abbv-brand-explorer-panel-container.abbv-active').css({'overflow-y': 'auto'})},1000);
	    	$('.abbv-content-container').addClass('abbv-freeze-top');
	    },
	    closeExplorer : function(){
	    	$('.abbv-brand-explorer-bar').removeClass('abbv-active');
	    	$('#brand-explorer-expand').fadeTo(300,1);
	    	$('.abbv-brand-explorer-panel-container-wrapper').fadeTo(300,1);
	    	$('.abbv-brand-explorer-panel-container').css({'max-height':'','overflow-y':'hidden'}).removeClass('abbv-active');
	    	setTimeout(function(){$('.abbv-content-container').removeClass('abbv-freeze-top');},300);
	    	setTimeout(function(){brandExplorer.goHome();},1000);
	    },
	    goHome : function (){
	    	if($activeSub != undefined){
	    		$activeSub.closest('.abbv-link-exploration').removeClass('abbv-active');
	   			$activeSub.closest('.abbv-link-grouping').removeClass('abbv-active');
	   			$linkExplore.css('height','');
	   			$activeSub = undefined;
	    	} 
	    	if ($activePanel != undefined){
	    		$homeSlider.removeClass('abbv-active');
	    		$activePanel.removeClass('abbv-active');
    		}
	    	userPos = 0;
	    	brandExplorer.analyzeButtons();
	    },
	    goBack : function(){
	    	if(userPos == 1){
	    		$activeSub.closest('.abbv-link-exploration').removeClass('abbv-active');
	   			$activeSub.closest('.abbv-link-grouping').removeClass('abbv-active');
	   			$linkExplore.css('height','');
	   			userPos = 0;
	   			$activeSub = undefined;
	    	} else if (userPos == 2) {
	    		userPos = $activeSub == undefined ? 0 : 1;
	    		$homeSlider.removeClass('abbv-active');
	    		$activePanel.removeClass('abbv-active');
	    		$activePanel = undefined;
	    	}
	    	brandExplorer.analyzeButtons();
	    },
	    navToSub : function($sub){
	    	$activeSub = $sub;
	    	let $grouping = $sub.closest('.abbv-link-grouping');
	    	$linkExplore.addClass('abbv-active');
	   		$grouping.addClass('abbv-active');
	   		$linkExplore.css('height',$grouping.find('ul').height());
	   		userPos = 1;
	   		brandExplorer.analyzeButtons();
	    },
	    navigateToPanel : function($panel){
	    	$activePanel = $panel;
	    	$activePanel.addClass('abbv-active');
	    	$homeSlider.addClass('abbv-active');
	   		userPos = 2;
	   		brandExplorer.analyzeButtons();
	    },
	    analyzeButtons : function(){
	    	if(userPos == 0){
	    		$explorerBackBTN.attr('disabled',true);
	   			$explorerHomeBTN.attr('disabled',true);
	    	} else {
	    		$explorerBackBTN.attr('disabled',false);
	   			$explorerHomeBTN.attr('disabled',false);
	    	}
	    },
	    diagnostic : function(){
	    	console.log(userPos);
	    },
	};
})();
// AbbVie Accordion Component
$(document).ready(function() {
  if(window.location.hash) {
    var urlHash = window.location.hash;
    var $anchorElement = $(urlHash);
    if($anchorElement != undefined){
      var triggerNeeded = $anchorElement.attr('data-trigger-for') != ''? true : false;
    }
    if(triggerNeeded){
      let $accordionObj = $('.'+$anchorElement.attr('data-trigger-for')).first().closest('.abbv-accordion');
      let $blade = $accordionObj.find('.'+$anchorElement.attr('data-trigger-for'));
      $('.'+$anchorElement.attr('data-trigger-for'))
      accordion.open($accordionObj, $blade);
    }
  }
  $(".abbv-accordion-blade > .abbv-accordion-blade-content, .abbv-accordion-blade-icon").on('click', function() {
      let $accordionObj = $(this).closest('.abbv-accordion');
      let $blade = $(this).parent('.abbv-accordion-blade');
      if($blade.hasClass('abbv-active')){
        accordion.close($accordionObj, $blade);
      } else {
        accordion.open($accordionObj, $blade);
      }
  });
});
var accordion = (function() {
    return {
      open: function($accordionObj, $blade) {
        var oneOpen = $accordionObj.hasClass('abbv-accordion-single');
        if(oneOpen){
          $accordionObj.find('.abbv-accordion-blade.abbv-active').each(function(){
            $(this).find('.abbv-accordion-content').first().delay(80).slideUp(500);
            $(this).removeClass('abbv-active');
            $(this).find('.abbv-accordion-blade-icon i').first().removeClass($accordionObj.attr('data-icon-closed')).addClass($accordionObj.attr('data-icon-open'));
          });
        }
        $blade.find('.abbv-accordion-content').first().delay(1).slideDown(500, function(){
          $blade.find('.abbv-img-slider').each(function(){
            initSlider(this);
          });
        });
        $blade.addClass('abbv-active');
        $blade.find('.abbv-accordion-blade-icon i').first().removeClass($accordionObj.attr('data-icon-open')).addClass($accordionObj.attr('data-icon-closed'));
      },
      close : function($accordionObj, $blade) {
        $blade.find('.abbv-accordion-content').first().delay(1).slideUp(500);
        $blade.removeClass('abbv-active');
        $blade.find('.abbv-accordion-blade-icon i').first().removeClass($accordionObj.attr('data-icon-closed')).addClass($accordionObj.attr('data-icon-open'));
      }
    };
})();

